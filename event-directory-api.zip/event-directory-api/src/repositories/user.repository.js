// src/repositories/user.repository.js
const db = require('../models');

/**
 * ==========================================
 * USER REPOSITORY
 * ==========================================
 * Capa de acceso a datos para usuarios.
 * Responsabilidad: Interactuar con la base de datos
 */

class UserRepository {
    
    /**
     * Buscar todos los usuarios
     */
    async findAll(options = {}) {
        return await db.User.findAll(options);
    }

    /**
     * Buscar usuario por ID
     */
    async findById(id, excludePassword = true) {
        const attributes = excludePassword 
            ? { exclude: ['password'] } 
            : undefined;

        return await db.User.findByPk(id, { attributes });
    }

    /**
     * Buscar usuario por email
     */
    async findByEmail(email, includePassword = false) {
        const attributes = includePassword 
            ? undefined 
            : { exclude: ['password'] };

        return await db.User.findOne({
            where: { email },
            attributes
        });
    }

    /**
     * Buscar un usuario con condiciones
     */
    async findOne(whereOptions, includePassword = false) {
        const attributes = includePassword 
            ? undefined 
            : { exclude: ['password'] };

        return await db.User.findOne({
            where: whereOptions,
            attributes
        });
    }

    /**
     * Crear usuario
     */
    async create(userData) {
        return await db.User.create(userData);
    }

    /**
     * Actualizar usuario
     */
    async update(user, updateData) {
        return await user.update(updateData);
    }

    /**
     * Eliminar usuario
     */
    async delete(user) {
        return await user.destroy();
    }

    /**
     * Contar usuarios
     */
    async count(whereOptions = {}) {
        return await db.User.count({ where: whereOptions });
    }

    /**
     * Verificar si un email ya existe
     */
    async emailExists(email) {
        const count = await this.count({ email });
        return count > 0;
    }

    /**
     * Buscar usuarios por rol
     */
    async findByRole(role, options = {}) {
        return await db.User.findAll({
            where: { role },
            ...options
        });
    }
}

module.exports = new UserRepository();
