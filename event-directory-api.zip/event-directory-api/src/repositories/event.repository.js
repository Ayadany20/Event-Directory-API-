// src/repositories/event.repository.js
const db = require('../models');
const { Op } = require('sequelize');

/**
 * ==========================================
 * EVENT REPOSITORY
 * ==========================================
 * Capa de acceso a datos para eventos.
 * Responsabilidad: Interactuar con la base de datos
 */

class EventRepository {
    
    /**
     * Buscar todos los eventos con opciones de query
     */
    async findAll(queryOptions) {
        return await db.Event.findAndCountAll(queryOptions);
    }

    /**
     * Buscar evento por ID
     */
    async findById(id, includeOptions = []) {
        return await db.Event.findByPk(id, { include: includeOptions });
    }

    /**
     * Buscar un evento con condiciones
     */
    async findOne(whereOptions, includeOptions = []) {
        return await db.Event.findOne({
            where: whereOptions,
            include: includeOptions
        });
    }

    /**
     * Crear evento
     */
    async create(eventData) {
        return await db.Event.create(eventData);
    }

    /**
     * Actualizar evento
     */
    async update(event, updateData) {
        return await event.update(updateData);
    }

    /**
     * Eliminar evento
     */
    async delete(event) {
        return await event.destroy();
    }

    /**
     * Contar eventos con condiciones
     */
    async count(whereOptions = {}) {
        return await db.Event.count({ where: whereOptions });
    }

    /**
     * Buscar eventos por categoría
     */
    async findByCategory(categoryId, options = {}) {
        return await db.Event.findAll({
            where: { categoryId },
            ...options
        });
    }

    /**
     * Buscar eventos por creador
     */
    async findByCreator(userId, options = {}) {
        return await db.Event.findAll({
            where: { createdBy: userId },
            ...options
        });
    }

    /**
     * Verificar si existe un evento
     */
    async exists(id) {
        const count = await this.count({ id });
        return count > 0;
    }
}

module.exports = new EventRepository();
