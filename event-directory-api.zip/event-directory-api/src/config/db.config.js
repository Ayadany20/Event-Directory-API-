// src/config/db.config.js

// Importa Sequelize y dotenv
const { Sequelize } = require('sequelize');
const dotenv = require('dotenv');

// Carga las variables de entorno si no se ha hecho en server.js
dotenv.config(); 

// 1. Inicializa la instancia de Sequelize con la conexión a SQL Server
const sequelize = new Sequelize(
    process.env.DB_NAME,      // Nombre de la base de datos
    process.env.DB_USER,      // Usuario (ej. SA)
    process.env.DB_PASSWORD,  // Contraseña
    {
        host: process.env.DB_HOST, // Host (ej. localhost)
        dialect: 'mssql',          // Dialecto para SQL Server
        dialectOptions: {
            // Opciones específicas del driver tedious
            options: {
                // Crucial para desarrollo local en Windows:
                trustServerCertificate: true, 
                encrypt: false, 
            },
        },
        logging: false, // Puedes cambiar a true o console.log para debugging
    }
);

// 2. Exporta la instancia de Sequelize
module.exports = sequelize;

// Nota: Los modelos, las asociaciones y el objeto 'db' se manejarán ahora en un archivo diferente 
// o directamente en server.js (o un archivo de configuración de modelos).