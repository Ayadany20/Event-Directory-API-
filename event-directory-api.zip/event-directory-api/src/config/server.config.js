// server.config.js
require('dotenv').config();

module.exports = {
    // Configuración del servidor
    port: process.env.PORT || 3000,
    nodeEnv: process.env.NODE_ENV || 'development',
    
    // Configuración de CORS
    cors: {
        origin: process.env.CORS_ORIGIN || '*',
        credentials: true,
        optionsSuccessStatus: 200
    },
    
    // ==================== CONFIGURACIÓN DE JWT ====================
    jwt: {
        // Secreto para firmar tokens (NUNCA compartir en repositorios públicos)
        secret: process.env.JWT_SECRET || 'default-secret-change-in-production',
        
        // Tiempo de expiración del token de acceso
        // Valores comunes:
        // - '15m' = 15 minutos (muy seguro, pero usuario re-autentica frecuentemente)
        // - '1h' = 1 hora (balanceado)
        // - '24h' = 24 horas (conveniente para desarrollo)
        expiresIn: process.env.JWT_EXPIRES_IN || '24h',
        
        // Tiempo de expiración del refresh token
        // Se usa para obtener un nuevo access token sin re-autenticar
        refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
        
        // Emisor del token (tu API)
        issuer: process.env.JWT_ISSUER || 'event-directory-api',
        
        // Audiencia (para quién es el token)
        audience: process.env.JWT_AUDIENCE || 'event-directory-app',
        
        // Algoritmo de firma (HS256 es el estándar)
        algorithm: 'HS256'
    },
    
    // Configuración de Email
    email: {
        service: process.env.EMAIL_SERVICE || 'gmail',
        host: process.env.EMAIL_HOST || 'smtp.gmail.com',
        port: process.env.EMAIL_PORT || 587,
        secure: process.env.EMAIL_SECURE === 'true' || false,
        user: process.env.EMAIL_USER || '',
        password: process.env.EMAIL_PASS || '',
        from: process.env.EMAIL_FROM || 'noreply@eventdirectory.com',
        fromName: process.env.EMAIL_FROM_NAME || 'Event Directory'
    },
    
    // Configuración de paginación
    pagination: {
        defaultLimit: 10,
        maxLimit: 100
    },
    
    // Configuración de rate limiting
    rateLimit: {
        windowMs: 15 * 60 * 1000, // 15 minutos
        max: 100 // límite de requests por ventana
    },
    
    // Configuración de la aplicación
    app: {
        name: 'Event Directory API',
        version: '1.0.0',
        apiPrefix: '/api/v1'
    }
};
