// src/config/database.js
const db = require('../models');
const serverConfig = require('./server.config');

const initializeDatabase = async (app) => {
    try {
        // Autenticar conexión
        await db.sequelize.authenticate();
        console.log('✅ Conexión a la base de datos SQL Server exitosa.');
        
        // Actualizar estado en app
        if (app) {
            app.locals.dbConnected = true;
            app.locals.dbError = null;
        }

        // Sincronizar modelos
        const syncOptions = serverConfig.nodeEnv === 'production' 
            ? { alter: false } 
            : { force: false }; // Cambiado de alter a force:false

        await db.sequelize.sync(syncOptions);
        console.log('✅ Modelos sincronizados con la base de datos.');
        console.log('📋 Tablas disponibles:');
        console.log('   - users');
        console.log('   - categories');
        console.log('   - events');
        console.log('   - event_registrations');
        console.log('   - confirmation_tokens');

        // Verificar conexión de email
        const emailService = require('../services/email.service');
        await emailService.verifyConnection();

        return true;

    } catch (err) {
        console.error('❌ Error al conectar con la base de datos:', err.message);
        
        if (app) {
            app.locals.dbConnected = false;
            app.locals.dbError = err.message;
        }
        
        if (serverConfig.nodeEnv === 'production') {
            console.error('🛑 La aplicación no puede iniciar sin base de datos.');
            process.exit(1);
        }

        return false;
    }
};

const closeDatabase = async () => {
    try {
        await db.sequelize.close();
        console.log('🔌 Conexión a base de datos cerrada.');
    } catch (err) {
        console.error('❌ Error al cerrar la base de datos:', err);
        throw err;
    }
};

module.exports = {
    initializeDatabase,
    closeDatabase
};
