// src/middlewares/auth.middleware.js
const { verifyToken: verifyJWT, extractTokenFromHeader } = require('../utils/jwt.util');
const db = require('../models');

/**
 * ==========================================
 * MIDDLEWARE DE AUTENTICACIÓN JWT
 * ==========================================
 * Este middleware verifica el token Bearer en el header Authorization
 * y adjunta el usuario autenticado a req.user
 */

/**
 * Middleware: Verificar token JWT (OBLIGATORIO)
 * 
 * USO: Para rutas que REQUIEREN autenticación
 * 
 * @example
 * router.get('/profile', verifyToken, controller.getProfile);
 * router.post('/events', verifyToken, controller.createEvent);
 */
const verifyToken = async (req, res, next) => {
    try {
        // 1. Extraer token del header Authorization
        const token = extractTokenFromHeader(req.headers.authorization);

        if (!token) {
            return res.status(401).json({
                success: false,
                message: 'No se proporcionó token de autenticación',
                error: 'Token requerido en header: Authorization: Bearer <token>'
            });
        }

        // 2. Verificar y decodificar token
        let decoded;
        try {
            decoded = verifyJWT(token);
        } catch (error) {
            return res.status(401).json({
                success: false,
                message: error.message,
                error: 'Token inválido o expirado'
            });
        }

        // 3. Verificar que el tipo sea 'access'
        if (decoded.type !== 'access') {
            return res.status(401).json({
                success: false,
                message: 'Tipo de token inválido',
                error: 'Use un access token'
            });
        }

        // 4. Buscar usuario en la base de datos
        const user = await db.User.findByPk(decoded.id, {
            attributes: { exclude: ['password'] } // No devolver contraseña
        });

        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Usuario no encontrado',
                error: 'El usuario asociado al token no existe'
            });
        }

        // 5. Verificar que el usuario esté activo
        if (!user.isActive) {
            return res.status(403).json({
                success: false,
                message: 'Usuario inactivo',
                error: 'Tu cuenta ha sido desactivada'
            });
        }

        // 6. Adjuntar usuario a la petición
        req.user = user;
        req.token = token;

        next();
    } catch (error) {
        console.error('Error en verifyToken middleware:', error);
        return res.status(500).json({
            success: false,
            message: 'Error al verificar autenticación',
            error: error.message
        });
    }
};

/**
 * Middleware: Verificar roles (usa después de verifyToken)
 * 
 * USO: Para rutas que requieren roles específicos
 * 
 * @param {...String} allowedRoles - Roles permitidos
 * @example
 * router.delete('/events/:id', verifyToken, checkRole('admin', 'organizer'), controller.delete);
 */
const checkRole = (...allowedRoles) => {
    return (req, res, next) => {
        // Verificar que el usuario esté autenticado
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'Autenticación requerida',
                error: 'Debe estar autenticado para acceder a este recurso'
            });
        }

        // Verificar si el rol del usuario está en los roles permitidos
        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                message: 'Acceso denegado',
                error: `Se requiere uno de los siguientes roles: ${allowedRoles.join(', ')}`,
                yourRole: req.user.role
            });
        }

        next();
    };
};

/**
 * Middleware: Requerir email verificado (usa después de verifyToken)
 * 
 * USO: Para rutas que requieren email verificado
 * 
 * @example
 * router.post('/events/:id/register', verifyToken, requireEmailVerification, controller.register);
 */
const requireEmailVerification = (req, res, next) => {
    if (!req.user) {
        return res.status(401).json({
            success: false,
            message: 'Autenticación requerida'
        });
    }

    if (!req.user.isEmailVerified) {
        return res.status(403).json({
            success: false,
            message: 'Email no verificado',
            error: 'Debes verificar tu email antes de realizar esta acción',
            hint: 'Revisa tu correo electrónico para el enlace de verificación'
        });
    }

    next();
};

/**
 * Middleware: Autenticación OPCIONAL
 * 
 * USO: Para rutas públicas que cambian comportamiento si el usuario está autenticado
 * 
 * @example
 * // Ejemplo: mostrar más detalles si el usuario está autenticado
 * router.get('/events', optionalAuth, controller.getAllEvents);
 */
const optionalAuth = async (req, res, next) => {
    try {
        const token = extractTokenFromHeader(req.headers.authorization);

        if (!token) {
            // No hay token, continuar sin autenticación
            req.user = null;
            return next();
        }

        // Intentar verificar token
        try {
            const decoded = verifyJWT(token);

            if (decoded.type === 'access') {
                const user = await db.User.findByPk(decoded.id, {
                    attributes: { exclude: ['password'] }
                });

                if (user && user.isActive) {
                    req.user = user;
                }
            }
        } catch (error) {
            // Token inválido o expirado, pero no es error porque es opcional
            req.user = null;
        }

        next();
    } catch (error) {
        console.error('Error en optionalAuth middleware:', error);
        req.user = null;
        next();
    }
};

module.exports = {
    verifyToken,
    checkRole,
    requireEmailVerification,
    optionalAuth
};
