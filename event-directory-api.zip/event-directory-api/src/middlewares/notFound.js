// src/middlewares/notFound.js
const notFound = (req, res) => {
    res.status(404).json({
        success: false,
        message: `Ruta no encontrada: ${req.method} ${req.url}`,
        timestamp: new Date().toISOString()
    });
};

module.exports = notFound;
