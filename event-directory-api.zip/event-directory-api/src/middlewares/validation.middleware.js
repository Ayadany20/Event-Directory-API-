// src/middlewares/validation.middleware.js
const Joi = require('joi');

/**
 * ==========================================
 * MIDDLEWARE DE VALIDACIÓN
 * ==========================================
 * Validaciones de entrada con Joi
 */

/**
 * Validación de registro de usuario
 */
const registerSchema = Joi.object({
    name: Joi.string().min(3).max(100).required().messages({
        'string.empty': 'El nombre es requerido',
        'string.min': 'El nombre debe tener al menos 3 caracteres',
        'string.max': 'El nombre no debe exceder 100 caracteres',
        'any.required': 'El nombre es requerido'
    }),
    email: Joi.string().email().required().messages({
        'string.empty': 'El email es requerido',
        'string.email': 'El email no es válido',
        'any.required': 'El email es requerido'
    }),
    password: Joi.string().min(6).max(100).required().messages({
        'string.empty': 'La contraseña es requerida',
        'string.min': 'La contraseña debe tener al menos 6 caracteres',
        'string.max': 'La contraseña no debe exceder 100 caracteres',
        'any.required': 'La contraseña es requerida'
    }),
    phone: Joi.string().pattern(/^[0-9]{10}$/).optional().allow('').messages({
        'string.pattern.base': 'El teléfono debe tener 10 dígitos'
    }),
    role: Joi.string().valid('user', 'organizer', 'admin').optional().messages({
        'any.only': 'El rol debe ser: user, organizer o admin'
    })
});

/**
 * Validación de login
 */
const loginSchema = Joi.object({
    email: Joi.string().email().required().messages({
        'string.empty': 'El email es requerido',
        'string.email': 'El email no es válido',
        'any.required': 'El email es requerido'
    }),
    password: Joi.string().required().messages({
        'string.empty': 'La contraseña es requerida',
        'any.required': 'La contraseña es requerida'
    })
});

/**
 * Validación de creación de evento
 */
const createEventSchema = Joi.object({
    title: Joi.string().min(5).max(200).required().messages({
        'string.empty': 'El título es requerido',
        'string.min': 'El título debe tener al menos 5 caracteres',
        'string.max': 'El título no debe exceder 200 caracteres',
        'any.required': 'El título es requerido'
    }),
    description: Joi.string().min(10).max(2000).required().messages({
        'string.empty': 'La descripción es requerida',
        'string.min': 'La descripción debe tener al menos 10 caracteres',
        'string.max': 'La descripción no debe exceder 2000 caracteres',
        'any.required': 'La descripción es requerida'
    }),
    categoryId: Joi.number().integer().positive().required().messages({
        'number.base': 'La categoría debe ser un número',
        'number.positive': 'La categoría debe ser un número positivo',
        'any.required': 'La categoría es requerida'
    }),
    maxCapacity: Joi.number().integer().min(1).required().messages({
        'number.base': 'La capacidad máxima debe ser un número',
        'number.min': 'La capacidad máxima debe ser al menos 1',
        'any.required': 'La capacidad máxima es requerida'
    }),
    startDate: Joi.date().iso().required().messages({
        'date.base': 'La fecha de inicio debe ser una fecha válida',
        'date.format': 'La fecha debe estar en formato ISO (YYYY-MM-DD)',
        'any.required': 'La fecha de inicio es requerida'
    }),
    endDate: Joi.date().iso().min(Joi.ref('startDate')).required().messages({
        'date.base': 'La fecha de fin debe ser una fecha válida',
        'date.min': 'La fecha de fin debe ser posterior a la fecha de inicio',
        'any.required': 'La fecha de fin es requerida'
    }),
    location: Joi.string().max(200).optional().allow('').messages({
        'string.max': 'La ubicación no debe exceder 200 caracteres'
    }),
    imageUrl: Joi.string().uri().optional().allow('').messages({
        'string.uri': 'La URL de la imagen no es válida'
    }),
    registrationDeadline: Joi.date().iso().optional().messages({
        'date.base': 'La fecha límite de registro debe ser una fecha válida'
    }),
    status: Joi.string().valid('draft', 'published', 'cancelled', 'completed').optional().messages({
        'any.only': 'El estado debe ser: draft, published, cancelled o completed'
    })
});

/**
 * Validación de actualización de evento
 */
const updateEventSchema = Joi.object({
    title: Joi.string().min(5).max(200).optional().messages({
        'string.min': 'El título debe tener al menos 5 caracteres',
        'string.max': 'El título no debe exceder 200 caracteres'
    }),
    description: Joi.string().min(10).max(2000).optional().messages({
        'string.min': 'La descripción debe tener al menos 10 caracteres',
        'string.max': 'La descripción no debe exceder 2000 caracteres'
    }),
    categoryId: Joi.number().integer().positive().optional().messages({
        'number.base': 'La categoría debe ser un número',
        'number.positive': 'La categoría debe ser un número positivo'
    }),
    maxCapacity: Joi.number().integer().min(1).optional().messages({
        'number.base': 'La capacidad máxima debe ser un número',
        'number.min': 'La capacidad máxima debe ser al menos 1'
    }),
    startDate: Joi.date().iso().optional().messages({
        'date.base': 'La fecha de inicio debe ser una fecha válida'
    }),
    endDate: Joi.date().iso().optional().messages({
        'date.base': 'La fecha de fin debe ser una fecha válida'
    }),
    location: Joi.string().max(200).optional().allow('').messages({
        'string.max': 'La ubicación no debe exceder 200 caracteres'
    }),
    imageUrl: Joi.string().uri().optional().allow('').messages({
        'string.uri': 'La URL de la imagen no es válida'
    }),
    registrationDeadline: Joi.date().iso().optional().messages({
        'date.base': 'La fecha límite de registro debe ser una fecha válida'
    }),
    status: Joi.string().valid('draft', 'published', 'cancelled', 'completed').optional().messages({
        'any.only': 'El estado debe ser: draft, published, cancelled o completed'
    })
}).min(1).messages({
    'object.min': 'Debe proporcionar al menos un campo para actualizar'
});

/**
 * Validación de envío de email
 */
const sendEmailSchema = Joi.object({
    to: Joi.string().email().required().messages({
        'string.empty': 'El destinatario es requerido',
        'string.email': 'El email del destinatario no es válido',
        'any.required': 'El destinatario es requerido'
    }),
    subject: Joi.string().min(1).max(200).required().messages({
        'string.empty': 'El asunto es requerido',
        'string.max': 'El asunto no debe exceder 200 caracteres',
        'any.required': 'El asunto es requerido'
    }),
    text: Joi.string().optional().allow(''),
    html: Joi.string().optional().allow('')
}).or('text', 'html').messages({
    'object.missing': 'Debe proporcionar "text" o "html" como contenido del email'
});

/**
 * Middleware genérico de validación
 */
const validate = (schema) => {
    return (req, res, next) => {
        const { error, value } = schema.validate(req.body, {
            abortEarly: false, // Retorna todos los errores, no solo el primero
            stripUnknown: true // Elimina campos no especificados en el schema
        });

        if (error) {
            const errors = error.details.map(detail => ({
                field: detail.path.join('.'),
                message: detail.message
            }));

            return res.status(400).json({
                success: false,
                message: 'Error de validación',
                errors
            });
        }

        // Reemplazar req.body con el valor validado y sanitizado
        req.body = value;
        next();
    };
};

module.exports = {
    validate,
    registerSchema,
    loginSchema,
    createEventSchema,
    updateEventSchema,
    sendEmailSchema
};
