// src/middlewares/errorHandler.js
const serverConfig = require('../config/server.config');

const errorHandler = (err, req, res, next) => {
    console.error('❌ Error:', err);

    const statusCode = err.statusCode || err.status || 500;

    const errorResponse = {
        success: false,
        message: serverConfig.nodeEnv === 'production' 
            ? 'Error interno del servidor' 
            : err.message,
        timestamp: new Date().toISOString()
    };

    // Stack trace solo en desarrollo
    if (serverConfig.nodeEnv === 'development') {
        errorResponse.stack = err.stack;
        errorResponse.error = err;
    }

    res.status(statusCode).json(errorResponse);
};

module.exports = errorHandler;
