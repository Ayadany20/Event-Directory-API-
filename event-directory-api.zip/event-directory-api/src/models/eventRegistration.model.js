// src/models/eventRegistration.model.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db.config');

const EventRegistration = sequelize.define('EventRegistration', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  eventId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'events',
      key: 'id'
    }
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id'
    },
    comment: 'Usuario registrado, null si es registro de invitado'
  },
  // Datos del asistente
  attendeeName: {
    type: DataTypes.STRING(200),
    allowNull: false,
    validate: {
      notEmpty: true,
      len: [2, 200]
    }
  },
  attendeeEmail: {
    type: DataTypes.STRING(100),
    allowNull: false,
    validate: {
      isEmail: true,
      notEmpty: true
    }
  },
  attendeePhone: {
    type: DataTypes.STRING(20),
    allowNull: true
  },
  attendeeDocument: {
    type: DataTypes.STRING(50),
    allowNull: true,
    comment: 'DNI, RFC, o identificación del asistente'
  },
  numberOfGuests: {
    type: DataTypes.INTEGER,
    defaultValue: 1,
    allowNull: false,
    validate: {
      min: 1,
      max: 10
    }
  },
  specialRequirements: {
    type: DataTypes.TEXT,
    allowNull: true,
    comment: 'Alergias, discapacidades, necesidades especiales'
  },
  // Estado del registro
  status: {
    type: DataTypes.ENUM('pending', 'confirmed', 'cancelled', 'attended', 'no_show'),
    defaultValue: 'pending',
    allowNull: false
  },
  registrationDate: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    allowNull: false
  },
  confirmationDate: {
    type: DataTypes.DATE,
    allowNull: true
  },
  cancellationDate: {
    type: DataTypes.DATE,
    allowNull: true
  },
  // Token de confirmación
  confirmationToken: {
    type: DataTypes.STRING(100),
    allowNull: true,
    unique: {
      name: 'unique_confirmation_token',
      msg: 'Token ya existe'
    }
  },
  confirmationTokenExpiry: {
    type: DataTypes.DATE,
    allowNull: true
  },
  isConfirmed: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    allowNull: false
  },
  // QR Code para check-in
  qrCode: {
    type: DataTypes.TEXT,
    allowNull: true,
    comment: 'QR code generado para check-in en el evento'
  },
  checkInDate: {
    type: DataTypes.DATE,
    allowNull: true
  },
  isCheckedIn: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    allowNull: false
  },
  // Información adicional
  notes: {
    type: DataTypes.TEXT,
    allowNull: true,
    comment: 'Notas adicionales del organizador'
  },
  paymentStatus: {
    type: DataTypes.ENUM('pending', 'completed', 'failed', 'refunded', 'free'),
    defaultValue: 'free',
    allowNull: false
  },
  paymentReference: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  amountPaid: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0.00,
    allowNull: false
  },
  // Notificaciones
  emailSent: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    allowNull: false
  },
  reminderSent: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    allowNull: false
  },
  // Metadata
  registrationSource: {
    type: DataTypes.STRING(50),
    allowNull: true,
    comment: 'web, mobile, api, etc.'
  },
  ipAddress: {
    type: DataTypes.STRING(45),
    allowNull: true
  }
}, {
  tableName: 'event_registrations',
  timestamps: true,
  indexes: [
    {
      name: 'idx_event_registrations_eventId',
      fields: ['eventId']
    },
    {
      name: 'idx_event_registrations_userId',
      fields: ['userId']
    },
    {
      name: 'idx_event_registrations_attendeeEmail',
      fields: ['attendeeEmail']
    },
    {
      name: 'idx_event_registrations_status',
      fields: ['status']
    },
    {
      name: 'idx_event_registrations_confirmationToken',
      fields: ['confirmationToken']
    },
    {
      name: 'idx_event_registrations_isConfirmed',
      fields: ['isConfirmed']
    },
    {
      name: 'idx_event_registrations_registrationDate',
      fields: ['registrationDate']
    }
  ],
  uniqueKeys: {
    unique_event_email: {
      fields: ['eventId', 'attendeeEmail']
    }
  }
});

module.exports = EventRegistration;
