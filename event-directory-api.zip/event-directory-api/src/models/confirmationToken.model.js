// src/models/confirmationToken.model.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db.config');

const ConfirmationToken = sequelize.define('ConfirmationToken', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  token: {
    type: DataTypes.STRING(255),
    allowNull: false,
    unique: {
      name: 'unique_token',
      msg: 'Token ya existe'
    },
    validate: {
      notEmpty: true
    }
  },
  type: {
    type: DataTypes.ENUM('event_registration', 'email_verification', 'password_reset'),
    allowNull: false,
    defaultValue: 'event_registration'
  },
  registrationId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'event_registrations',
      key: 'id'
    },
    comment: 'ID del registro de evento si aplica'
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id'
    },
    comment: 'ID del usuario si aplica'
  },
  email: {
    type: DataTypes.STRING(100),
    allowNull: false,
    validate: {
      isEmail: true
    }
  },
  expiresAt: {
    type: DataTypes.DATE,
    allowNull: false,
    validate: {
      isDate: true
    }
  },
  isUsed: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    allowNull: false
  },
  usedAt: {
    type: DataTypes.DATE,
    allowNull: true
  },
  isExpired: {
    type: DataTypes.VIRTUAL,
    get() {
      return new Date() > this.expiresAt;
    }
  },
  ipAddress: {
    type: DataTypes.STRING(45),
    allowNull: true
  },
  userAgent: {
    type: DataTypes.STRING(500),
    allowNull: true
  },
  attempts: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
    allowNull: false,
    comment: 'Número de intentos de uso del token'
  },
  maxAttempts: {
    type: DataTypes.INTEGER,
    defaultValue: 3,
    allowNull: false
  }
}, {
  tableName: 'confirmation_tokens',
  timestamps: true,
  indexes: [
    {
      name: 'idx_confirmation_tokens_email',
      fields: ['email']
    },
    {
      name: 'idx_confirmation_tokens_type',
      fields: ['type']
    },
    {
      name: 'idx_confirmation_tokens_registrationId',
      fields: ['registrationId']
    },
    {
      name: 'idx_confirmation_tokens_userId',
      fields: ['userId']
    },
    {
      name: 'idx_confirmation_tokens_isUsed',
      fields: ['isUsed']
    },
    {
      name: 'idx_confirmation_tokens_expiresAt',
      fields: ['expiresAt']
    }
  ]
});

module.exports = ConfirmationToken;
