// src/models/event.model.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db.config');

const Event = sequelize.define('Event', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  title: {
    type: DataTypes.STRING(200),
    allowNull: false,
    validate: {
      notEmpty: true,
      len: [5, 200]
    }
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false,
    validate: {
      notEmpty: true,
      len: [10, 5000]
    }
  },
  shortDescription: {
    type: DataTypes.STRING(500),
    allowNull: true
  },
  location: {
    type: DataTypes.STRING(300),
    allowNull: false,
    validate: {
      notEmpty: true
    }
  },
  address: {
    type: DataTypes.STRING(500),
    allowNull: true
  },
  city: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  state: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  country: {
    type: DataTypes.STRING(100),
    allowNull: true,
    defaultValue: 'México'
  },
  startDate: {
    type: DataTypes.DATE,
    allowNull: false,
    validate: {
      isDate: true
    }
  },
  endDate: {
    type: DataTypes.DATE,
    allowNull: false,
    validate: {
      isDate: true
    }
  },
  // CUPO MÁXIMO DEL EVENTO
  maxCapacity: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 100,
    validate: {
      min: 1,
      max: 100000,
      notEmpty: true
    },
    comment: 'Cupo máximo total del evento'
  },
  // ESPACIOS DISPONIBLES (se actualiza con cada registro)
  availableSpots: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 100,
    validate: {
      min: 0
    },
    comment: 'Espacios disponibles en tiempo real'
  },
  // ESPACIOS OCUPADOS (calculado)
  occupiedSpots: {
    type: DataTypes.VIRTUAL,
    get() {
      return this.maxCapacity - this.availableSpots;
    }
  },
  // PORCENTAJE DE OCUPACIÓN (calculado)
  occupancyPercentage: {
    type: DataTypes.VIRTUAL,
    get() {
      return ((this.occupiedSpots / this.maxCapacity) * 100).toFixed(2);
    }
  },
  // INDICA SI EL EVENTO ESTÁ LLENO
  isFull: {
    type: DataTypes.VIRTUAL,
    get() {
      return this.availableSpots === 0;
    }
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 0.00,
    validate: {
      min: 0
    }
  },
  isFree: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
    allowNull: false
  },
  // URL DE LA IMAGEN PRINCIPAL DEL EVENTO
  imageUrl: {
    type: DataTypes.STRING(500),
    allowNull: true,
    validate: {
      isUrl: true
    },
    comment: 'URL de la imagen principal del evento'
  },
  // URL DEL FLYER DEL EVENTO
  flyerUrl: {
    type: DataTypes.STRING(500),
    allowNull: true,
    validate: {
      isUrl: true
    },
    comment: 'URL del flyer/poster promocional del evento'
  },
  // GALERÍA DE IMÁGENES ADICIONALES
  galleryUrls: {
    type: DataTypes.TEXT,
    allowNull: true,
    comment: 'URLs de imágenes adicionales separadas por comas',
    get() {
      const rawValue = this.getDataValue('galleryUrls');
      return rawValue ? rawValue.split(',').map(url => url.trim()) : [];
    },
    set(urls) {
      if (Array.isArray(urls)) {
        this.setDataValue('galleryUrls', urls.join(','));
      } else {
        this.setDataValue('galleryUrls', urls);
      }
    }
  },
  organizerName: {
    type: DataTypes.STRING(200),
    allowNull: true
  },
  organizerEmail: {
    type: DataTypes.STRING(100),
    allowNull: true,
    validate: {
      isEmail: true
    }
  },
  organizerPhone: {
    type: DataTypes.STRING(20),
    allowNull: true
  },
  status: {
    type: DataTypes.ENUM('draft', 'published', 'cancelled', 'completed', 'sold_out'),
    defaultValue: 'draft',
    allowNull: false
  },
  isPublished: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    allowNull: false
  },
  publishedAt: {
    type: DataTypes.DATE,
    allowNull: true
  },
  slug: {
    type: DataTypes.STRING(250),
    allowNull: false,
    unique: {
      name: 'unique_event_slug',
      msg: 'Este slug ya existe'
    },
    validate: {
      notEmpty: true,
      is: /^[a-z0-9-]+$/
    }
  },
  tags: {
    type: DataTypes.STRING(500),
    allowNull: true,
    comment: 'Etiquetas separadas por comas',
    get() {
      const rawValue = this.getDataValue('tags');
      return rawValue ? rawValue.split(',').map(tag => tag.trim()) : [];
    },
    set(tags) {
      if (Array.isArray(tags)) {
        this.setDataValue('tags', tags.join(','));
      } else {
        this.setDataValue('tags', tags);
      }
    }
  },
  requiresApproval: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    allowNull: false,
    comment: 'Si requiere aprobación manual del organizador'
  },
  allowWaitlist: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
    allowNull: false,
    comment: 'Si permite lista de espera cuando esté lleno'
  },
  categoryId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'categories',
      key: 'id'
    }
  },
  createdBy: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id'
    }
  }
}, {
  tableName: 'events',
  timestamps: true,
  indexes: [
    {
      name: 'idx_events_status',
      fields: ['status']
    },
    {
      name: 'idx_events_startDate',
      fields: ['startDate']
    },
    {
      name: 'idx_events_categoryId',
      fields: ['categoryId']
    },
    {
      name: 'idx_events_createdBy',
      fields: ['createdBy']
    },
    {
      name: 'idx_events_isPublished',
      fields: ['isPublished']
    },
    {
      name: 'idx_events_availableSpots',
      fields: ['availableSpots']
    }
  ]
});

module.exports = Event;
