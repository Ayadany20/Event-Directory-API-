// src/models/index.js
// ==========================================
// ARCHIVO PRINCIPAL DE MODELOS Y RELACIONES
// ==========================================
// Este archivo centraliza:
// 1. La importación de todos los modelos
// 2. La definición de relaciones entre modelos
// 3. La exportación de un objeto 'db' con todo lo necesario
// ==========================================

const sequelize = require('../config/db.config');
const Sequelize = require('sequelize');

// ==========================================
// IMPORTAR TODOS LOS MODELOS
// ==========================================
const User = require('./user.model');
const Category = require('./category.model');
const Event = require('./event.model');
const EventRegistration = require('./eventRegistration.model');
const ConfirmationToken = require('./confirmationToken.model');

// ==========================================
// DEFINIR RELACIONES ENTRE MODELOS
// ==========================================

/**
 * RELACIÓN: Categoría - Evento (1:N)
 * -----------------------------------
 * Descripción:
 * - Una categoría puede tener MUCHOS eventos
 * - Un evento pertenece a UNA categoría
 * 
 * Ejemplo:
 * - Categoría "Deportes" -> Eventos: "Maratón", "Partido de fútbol", etc.
 * - Evento "Maratón" -> Categoría: "Deportes"
 * 
 * Opciones:
 * - foreignKey: Campo que almacena la relación en la tabla 'events'
 * - as: Alias para usar en las consultas
 * - onDelete: 'NO ACTION' = No permite borrar categoría si tiene eventos
 * - onUpdate: 'CASCADE' = Si se actualiza el ID de categoría, actualiza en eventos
 */
Category.hasMany(Event, { 
  foreignKey: 'categoryId', 
  as: 'events',
  onDelete: 'NO ACTION',
  onUpdate: 'CASCADE'
});

Event.belongsTo(Category, { 
  foreignKey: 'categoryId', 
  as: 'category' 
});

/**
 * RELACIÓN: Usuario - Evento (1:N) - Relación de CREADOR
 * --------------------------------------------------------
 * Descripción:
 * - Un usuario puede CREAR muchos eventos
 * - Un evento fue CREADO POR un usuario
 * 
 * Ejemplo:
 * - Usuario "Juan" -> Eventos creados: "Concierto Rock", "Conferencia Tech"
 * - Evento "Concierto Rock" -> Creado por: "Juan"
 * 
 * Opciones:
 * - as: 'createdEvents' y 'creator' para diferenciar del usuario que asiste
 * - onDelete: 'NO ACTION' = No permite borrar usuario si tiene eventos creados
 * - onUpdate: 'CASCADE' = Si cambia el ID del usuario, actualiza en eventos
 */
User.hasMany(Event, { 
  foreignKey: 'createdBy', 
  as: 'createdEvents',
  onDelete: 'NO ACTION',
  onUpdate: 'CASCADE'
});

Event.belongsTo(User, { 
  foreignKey: 'createdBy', 
  as: 'creator' 
});

/**
 * RELACIÓN: Evento - Registro de Evento (1:N)
 * --------------------------------------------
 * Descripción:
 * - Un evento puede tener MUCHOS registros de asistentes
 * - Un registro pertenece a UN evento
 * 
 * Ejemplo:
 * - Evento "Concierto Rock" -> Registros: Pedro, María, Luis, etc.
 * - Registro de "Pedro" -> Evento: "Concierto Rock"
 * 
 * Opciones:
 * - as: 'registrations' = Lista de todos los asistentes registrados
 * - onDelete: 'CASCADE' = Si se borra el evento, se borran TODOS sus registros
 * - onUpdate: 'CASCADE' = Si cambia el ID del evento, actualiza en registros
 */
Event.hasMany(EventRegistration, { 
  foreignKey: 'eventId', 
  as: 'registrations',
  onDelete: 'CASCADE',
  onUpdate: 'CASCADE'
});

EventRegistration.belongsTo(Event, { 
  foreignKey: 'eventId', 
  as: 'event' 
});

/**
 * RELACIÓN: Usuario - Registro de Evento (1:N) - Relación de ASISTENTE
 * ----------------------------------------------------------------------
 * Descripción:
 * - Un usuario puede REGISTRARSE a muchos eventos
 * - Un registro PUEDE pertenecer a un usuario (null si es invitado sin cuenta)
 * 
 * Ejemplo:
 * - Usuario "María" -> Registros: "Concierto Rock", "Maratón", "Conferencia"
 * - Registro del evento -> Usuario: "María" (o null si registró sin cuenta)
 * 
 * Opciones:
 * - as: 'eventRegistrations' = Todos los eventos a los que se registró
 * - onDelete: 'SET NULL' = Si se borra el usuario, el registro queda pero sin usuario
 *   (esto permite que los registros de invitados se mantengan)
 * - onUpdate: 'CASCADE' = Si cambia el ID del usuario, actualiza en registros
 */
User.hasMany(EventRegistration, { 
  foreignKey: 'userId', 
  as: 'eventRegistrations',
  onDelete: 'SET NULL',
  onUpdate: 'CASCADE'
});

EventRegistration.belongsTo(User, { 
  foreignKey: 'userId', 
  as: 'user' 
});

/**
 * RELACIÓN: Registro de Evento - Token de Confirmación (1:N)
 * -----------------------------------------------------------
 * Descripción:
 * - Un registro puede tener VARIOS tokens a lo largo del tiempo
 *   (Si un token expira, se puede generar uno nuevo)
 * - Un token pertenece a UN registro específico
 * 
 * Ejemplo:
 * - Registro de "Pedro" -> Tokens: "abc123" (expiró), "xyz789" (actual)
 * - Token "xyz789" -> Registro: "Pedro para Concierto Rock"
 * 
 * Opciones:
 * - as: 'confirmationTokens' = Historial de tokens del registro
 * - onDelete: 'CASCADE' = Si se cancela el registro, se borran sus tokens
 * - onUpdate: 'CASCADE' = Si cambia el ID del registro, actualiza en tokens
 */
EventRegistration.hasMany(ConfirmationToken, { 
  foreignKey: 'registrationId', 
  as: 'confirmationTokens',
  onDelete: 'CASCADE',
  onUpdate: 'CASCADE'
});

ConfirmationToken.belongsTo(EventRegistration, { 
  foreignKey: 'registrationId', 
  as: 'registration' 
});

/**
 * RELACIÓN: Usuario - Token de Confirmación (1:N)
 * ------------------------------------------------
 * Descripción:
 * - Un usuario puede tener VARIOS tokens de diferentes tipos:
 *   * Confirmación de email
 *   * Reset de contraseña
 *   * Confirmación de asistencia a eventos
 * - Un token pertenece a UN usuario
 * 
 * Ejemplo:
 * - Usuario "Ana" -> Tokens: "email_verify_123", "password_reset_456"
 * - Token "email_verify_123" -> Usuario: "Ana"
 * 
 * Opciones:
 * - as: 'tokens' = Todos los tokens del usuario
 * - onDelete: 'CASCADE' = Si se borra el usuario, se borran sus tokens
 * - onUpdate: 'CASCADE' = Si cambia el ID del usuario, actualiza en tokens
 */
User.hasMany(ConfirmationToken, { 
  foreignKey: 'userId', 
  as: 'tokens',
  onDelete: 'CASCADE',
  onUpdate: 'CASCADE'
});

ConfirmationToken.belongsTo(User, { 
  foreignKey: 'userId', 
  as: 'user' 
});

// ==========================================
// CREAR OBJETO DB CON TODO LO NECESARIO
// ==========================================

const db = {
  // Instancia de Sequelize configurada (para ejecutar queries)
  sequelize,
  
  // Clase Sequelize (para usar tipos de datos, operadores, etc.)
  Sequelize,
  
  // ==========================================
  // MODELOS
  // ==========================================
  User,                 // Usuarios del sistema
  Category,             // Categorías de eventos
  Event,                // Eventos publicados
  EventRegistration,    // Registros de asistentes a eventos
  ConfirmationToken,    // Tokens de confirmación/verificación
};

// ==========================================
// MÉTODOS HELPER (Utilidades)
// ==========================================

/**
 * Sincronizar todos los modelos con la base de datos
 * 
 * @param {Object} options - Opciones de sincronización
 * @param {boolean} options.force - Si es true, BORRA y recrea todas las tablas (¡CUIDADO!)
 * @param {boolean} options.alter - Si es true, actualiza las tablas sin borrar datos
 * @returns {Promise<void>}
 * 
 * Ejemplos de uso:
 * - await db.sync(); // Solo crea tablas que no existen
 * - await db.sync({ alter: true }); // Actualiza estructura de tablas existentes
 * - await db.sync({ force: true }); // BORRA TODO y recrea (solo en desarrollo)
 */
db.sync = async (options = {}) => {
  try {
    await sequelize.sync(options);
    console.log('✅ Base de datos sincronizada correctamente.');
  } catch (error) {
    console.error('❌ Error al sincronizar base de datos:', error.message);
    throw error;
  }
};

/**
 * Verificar que la conexión a la base de datos funciona
 * 
 * @returns {Promise<boolean>} - true si conecta, false si falla
 * 
 * Ejemplo de uso:
 * const isConnected = await db.testConnection();
 * if (isConnected) {
 *   console.log('Base de datos lista');
 * }
 */
db.testConnection = async () => {
  try {
    await sequelize.authenticate();
    console.log('✅ Conexión a base de datos exitosa.');
    return true;
  } catch (error) {
    console.error('❌ Error de conexión a base de datos:', error.message);
    return false;
  }
};

/**
 * Cerrar la conexión a la base de datos de forma limpia
 * 
 * @returns {Promise<void>}
 * 
 * Ejemplo de uso:
 * process.on('SIGTERM', async () => {
 *   await db.close();
 *   process.exit(0);
 * });
 */
db.close = async () => {
  try {
    await sequelize.close();
    console.log('🔌 Conexión a base de datos cerrada correctamente.');
  } catch (error) {
    console.error('❌ Error al cerrar conexión a base de datos:', error.message);
    throw error;
  }
};

// ==========================================
// EXPORTAR OBJETO DB
// ==========================================
// Este objeto se puede importar en cualquier parte de la app:
// const db = require('./models');
// const { User, Event } = db;

module.exports = db;
