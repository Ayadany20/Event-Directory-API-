// src/controllers/auth.controller.js
const authService = require('../services/auth.service');

/**
 * ==========================================
 * AUTH CONTROLLER
 * ==========================================
 * Maneja peticiones HTTP y delega lógica al servicio.
 * Responsabilidad: Request/Response, validación de entrada, códigos HTTP
 */

/**
 * Registrar nuevo usuario
 * POST /api/v1/auth/register
 */
const register = async (req, res, next) => {
    try {
        const result = await authService.register(req.body);
        
        res.status(201).json({
            success: true,
            message: 'Usuario registrado exitosamente',
            data: result
        });
    } catch (error) {
        if (error.message.includes('requeridos') || 
            error.message.includes('inválido') || 
            error.message.includes('debe tener') ||
            error.message.includes('ya está registrado')) {
            return res.status(400).json({
                success: false,
                message: error.message
            });
        }
        next(error);
    }
};

/**
 * Iniciar sesión
 */
const login = async (req, res, next) => {
    try {
        const result = await authService.login(req.body);
        
        res.status(200).json({
            success: true,
            message: 'Login exitoso',
            data: result
        });
    } catch (error) {
        if (error.message.includes('inválidas')) {
            return res.status(401).json({
                success: false,
                message: error.message
            });
        }
        if (error.message.includes('inactivo')) {
            return res.status(403).json({
                success: false,
                message: error.message
            });
        }
        next(error);
    }
};

/**
 * Recuperar contraseña
 */
const forgotPassword = async (req, res, next) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                success: false,
                message: 'Email es requerido'
            });
        }

        const result = await authService.forgotPassword(email);

        res.status(200).json({
            success: true,
            ...result
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Restablecer contraseña
 * POST /api/v1/auth/reset-password
 */
const resetPassword = async (req, res, next) => {
    try {
        const { token, newPassword } = req.body;
        
        const result = await authService.resetPassword(token, newPassword);
        
        res.status(200).json({
            success: true,
            ...result
        });
    } catch (error) {
        if (error.message.includes('debe tener')) {
            return res.status(400).json({
                success: false,
                message: error.message
            });
        }
        next(error);
    }
};

/**
 * Obtener perfil del usuario autenticado
 * GET /api/v1/auth/profile
 * 
 * 🔒 REQUIERE: verifyToken middleware
 */
const getProfile = async (req, res, next) => {
    try {
        const user = await authService.getProfile(req.user.id);
        
        res.status(200).json({
            success: true,
            message: 'Perfil obtenido exitosamente',
            data: { user }
        });
    } catch (error) {
        if (error.message === 'Usuario no encontrado') {
            return res.status(404).json({
                success: false,
                message: error.message
            });
        }
        next(error);
    }
};

/**
 * Actualizar perfil del usuario autenticado
 * PUT /api/v1/auth/profile
 * 
 * 🔒 REQUIERE: verifyToken middleware
 */
const updateProfile = async (req, res, next) => {
    try {
        const user = await authService.updateProfile(req.user.id, req.body);
        
        res.status(200).json({
            success: true,
            message: 'Perfil actualizado exitosamente',
            data: { user }
        });
    } catch (error) {
        if (error.message === 'Usuario no encontrado') {
            return res.status(404).json({
                success: false,
                message: error.message
            });
        }
        next(error);
    }
};

module.exports = {
    register,
    login,
    forgotPassword,
    resetPassword,
    getProfile,
    updateProfile
};
