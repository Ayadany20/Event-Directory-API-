// src/controllers/event.controller.js
const eventService = require('../services/event.service');

/**
 * ==========================================
 * EVENT CONTROLLER
 * ==========================================
 * Maneja peticiones HTTP y delega lógica al servicio.
 * Responsabilidad: Request/Response, validación de entrada, códigos HTTP
 */

/**
 * Obtener todos los eventos con filtros y paginación
 * GET /api/v1/events
 */
const getAllEvents = async (req, res, next) => {
    try {
        const result = await eventService.getAllEvents(req.query);
        
        res.status(200).json({
            success: true,
            data: result
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Obtener evento por ID
 * GET /api/v1/events/:id
 */
const getEventById = async (req, res, next) => {
    try {
        const event = await eventService.getEventById(req.params.id);
        
        res.status(200).json({
            success: true,
            data: { event }
        });
    } catch (error) {
        if (error.message === 'Evento no encontrado') {
            return res.status(404).json({
                success: false,
                message: error.message
            });
        }
        next(error);
    }
};

/**
 * Crear nuevo evento
 * POST /api/v1/events
 * 
 * 🔒 REQUIERE: verifyToken middleware
 */
const createEvent = async (req, res, next) => {
    try {
        const event = await eventService.createEvent(req.body, req.user.id);
        
        res.status(201).json({
            success: true,
            message: 'Evento creado exitosamente',
            data: { event }
        });
    } catch (error) {
        if (error.message.includes('requeridos') || error.message.includes('debe ser')) {
            return res.status(400).json({
                success: false,
                message: error.message
            });
        }
        next(error);
    }
};

/**
 * Actualizar evento
 * PUT /api/v1/events/:id
 * 
 * 🔒 REQUIERE: verifyToken middleware
 */
const updateEvent = async (req, res, next) => {
    try {
        const event = await eventService.updateEvent(
            req.params.id, 
            req.body, 
            req.user.id, 
            req.user.role
        );
        
        res.status(200).json({
            success: true,
            message: 'Evento actualizado exitosamente',
            data: { event }
        });
    } catch (error) {
        if (error.message === 'Evento no encontrado') {
            return res.status(404).json({
                success: false,
                message: error.message
            });
        }
        if (error.message.includes('permiso') || error.message.includes('capacidad')) {
            return res.status(403).json({
                success: false,
                message: error.message
            });
        }
        next(error);
    }
};

/**
 * Eliminar evento
 * DELETE /api/v1/events/:id
 * 
 * 🔒 REQUIERE: verifyToken middleware
 */
const deleteEvent = async (req, res, next) => {
    try {
        await eventService.deleteEvent(req.params.id, req.user.id, req.user.role);
        
        res.status(200).json({
            success: true,
            message: 'Evento eliminado exitosamente'
        });
    } catch (error) {
        if (error.message === 'Evento no encontrado') {
            return res.status(404).json({
                success: false,
                message: error.message
            });
        }
        if (error.message.includes('permiso') || error.message.includes('registros')) {
            return res.status(403).json({
                success: false,
                message: error.message
            });
        }
        next(error);
    }
};

module.exports = {
    getAllEvents,
    getEventById,
    createEvent,
    updateEvent,
    deleteEvent
};
