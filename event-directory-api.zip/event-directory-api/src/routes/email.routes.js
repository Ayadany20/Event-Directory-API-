// src/routes/email.routes.js
const express = require('express');
const router = express.Router();
const emailController = require('../controllers/email.controller');
const { verifyToken, checkRole } = require('../middlewares/auth.middleware');

/**
 * ==========================================
 * EMAIL ROUTES
 * ==========================================
 * Rutas para gestión de envío de emails
 */

/**
 * @route   GET /api/v1/email/verify
 * @desc    Verificar conexión con el servidor de email
 * @access  Private (Admin)
 */
router.get('/verify', verifyToken, checkRole('admin'), emailController.verifyEmailConnection);

/**
 * @route   POST /api/v1/email/send
 * @desc    Enviar email genérico
 * @access  Private (Admin, Organizer)
 * @body    { to, subject, text, html }
 */
router.post('/send', verifyToken, checkRole('admin', 'organizer'), emailController.sendEmail);

/**
 * @route   POST /api/v1/email/test
 * @desc    Enviar email de prueba
 * @access  Private (Admin)
 * @body    { to }
 */
router.post('/test', verifyToken, checkRole('admin'), emailController.sendTestEmail);

/**
 * @route   POST /api/v1/email/welcome
 * @desc    Enviar email de bienvenida
 * @access  Private (Admin)
 * @body    { name, email, role }
 */
router.post('/welcome', verifyToken, checkRole('admin'), emailController.sendWelcomeEmail);

/**
 * @route   POST /api/v1/email/event-confirmation
 * @desc    Enviar email de confirmación de evento
 * @access  Private (Admin, Organizer)
 * @body    { userName, userEmail, eventTitle, eventDescription, eventStartDate, eventLocation }
 */
router.post('/event-confirmation', verifyToken, checkRole('admin', 'organizer'), emailController.sendEventConfirmationEmail);

module.exports = router;
