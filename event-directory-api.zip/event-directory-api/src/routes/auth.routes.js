// src/routes/auth.routes.js
const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const { verifyToken, checkRole, requireEmailVerification } = require('../middlewares/auth.middleware');

/**
 * ==========================================
 * RUTAS DE AUTENTICACIÓN
 * ==========================================
 * Todas las rutas relacionadas con registro, login y gestión de usuarios
 */

// ==================== RUTAS PÚBLICAS (sin autenticación) ====================
/**
 * @swagger
 * /api/v1/auth/register:
 *   post:
 *     summary: Registrar un nuevo usuario
 *     tags: [Autenticación]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterRequest'
 *     responses:
 *       201:
 *         description: Usuario registrado exitosamente
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Error de validación (campos faltantes o inválidos)
 *       500:
 *         description: Error del servidor
 */
router.post('/register', authController.register);

/**
 * @swagger
 * /api/v1/auth/login:
 *   post:
 *     summary: Iniciar sesión con email y contraseña
 *     tags: [Autenticación]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginRequest'
 *     responses:
 *       200:
 *         description: Login exitoso, retorna tokens JWT
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       401:
 *         description: Credenciales inválidas
 *       403:
 *         description: Usuario inactivo
 *       500:
 *         description: Error del servidor
 */
router.post('/login', authController.login);

/**
 * @swagger
 * /api/v1/auth/forgot-password:
 *   post:
 *     summary: Solicitar restablecimiento de contraseña
 *     tags: [Autenticación]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *                 example: mesinoayadany14@gmail.com
 *     responses:
 *       200:
 *         description: Email de restablecimiento enviado
 *       400:
 *         description: Email requerido
 *       500:
 *         description: Error del servidor
 */
router.post('/forgot-password', authController.forgotPassword);

/**
 * @swagger
 * /api/v1/auth/reset-password:
 *   post:
 *     summary: Restablecer contraseña con token
 *     tags: [Autenticación]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               token:
 *                 type: string
 *               newPassword:
 *                 type: string
 *     responses:
 *       200:
 *         description: Contraseña restablecida exitosamente
 *       400:
 *         description: Token inválido o contraseña no válida
 *       500:
 *         description: Error del servidor
 */
router.post('/reset-password', authController.resetPassword);

// ==================== RUTAS PROTEGIDAS (requieren token) ====================
// Para usar estas rutas, incluir header: Authorization: Bearer <token>

// Ver perfil del usuario autenticado
/**
 * @swagger
 * /api/v1/auth/profile:
 *   get:
 *     summary: Obtener perfil del usuario autenticado
 *     tags: [Autenticación]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Perfil obtenido exitosamente
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       401:
 *         description: No autenticado o token inválido
 *       404:
 *         description: Usuario no encontrado
 *       500:
 *         description: Error del servidor
 */
router.get('/profile', verifyToken, authController.getProfile);

/**
 * @swagger
 * /api/v1/auth/profile:
 *   put:
 *     summary: Actualizar perfil del usuario autenticado
 *     tags: [Autenticación]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               phone:
 *                 type: string
 *               email:
 *                 type: string
 *     responses:
 *       200:
 *         description: Perfil actualizado exitosamente
 *       401:
 *         description: No autenticado
 *       404:
 *         description: Usuario no encontrado
 *       500:
 *         description: Error del servidor
 */
router.put('/profile', verifyToken, authController.updateProfile);

/**
 * ==========================================
 * EJEMPLOS DE IMPLEMENTACIÓN JWT
 * ==========================================
 * 
 * 1. RUTA CON AUTENTICACIÓN OBLIGATORIA:
 *    router.get('/profile', verifyToken, authController.getProfile);
 * 
 * 2. RUTA CON VERIFICACIÓN DE ROL:
 *    router.delete('/users/:id', verifyToken, checkRole('admin'), controller.deleteUser);
 * 
 * 3. RUTA CON MÚLTIPLES ROLES:
 *    router.post('/events', verifyToken, checkRole('admin', 'organizer'), controller.createEvent);
 * 
 * 4. RUTA QUE REQUIERE EMAIL VERIFICADO:
 *    router.post('/events/:id/register', verifyToken, requireEmailVerification, controller.register);
 * 
 * 5. COMBINACIÓN DE MIDDLEWARES:
 *    router.put('/events/:id', 
 *      verifyToken, 
 *      checkRole('admin', 'organizer'), 
 *      requireEmailVerification, 
 *      controller.updateEvent
 *    );
 */

module.exports = router;
