// src/routes/event.routes.js
const express = require('express');
const router = express.Router();
const eventController = require('../controllers/event.controller');
const { verifyToken, checkRole, optionalAuth } = require('../middlewares/auth.middleware');

/**
 * ==========================================
 * RUTAS DE EVENTOS
 * ==========================================
 * Por ahora NO tienen JWT implementado, pero aquí se muestra cómo hacerlo
 */

// ==================== RUTAS PÚBLICAS (sin autenticación) ====================
/**
 * @swagger
 * /api/v1/events:
 *   get:
 *     summary: Obtener lista de todos los eventos
 *     tags: [Eventos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Número de página
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: Límite de eventos por página
 *       - in: query
 *         name: categoryId
 *         schema:
 *           type: integer
 *         description: Filtrar por categoría
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Buscar en título o descripción
 *     responses:
 *       200:
 *         description: Lista de eventos obtenida
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       401:
 *         description: No autenticado
 *       500:
 *         description: Error del servidor
 */
router.get('/',  checkRole('admin'), eventController.getAllEvents);

/**
 * @swagger
 * /api/v1/events/{id}:
 *   get:
 *     summary: Obtener evento por ID
 *     tags: [Eventos]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del evento
 *     responses:
 *       200:
 *         description: Evento obtenido exitosamente
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       404:
 *         description: Evento no encontrado
 *       500:
 *         description: Error del servidor
 */
router.get('/:id', eventController.getEventById);

/**
 * @swagger
 * /api/v1/events:
 *   post:
 *     summary: Crear un nuevo evento
 *     tags: [Eventos]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateEventRequest'
 *     responses:
 *       201:
 *         description: Evento creado exitosamente
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Datos inválidos o faltantes
 *       401:
 *         description: No autenticado
 *       500:
 *         description: Error del servidor
 */
router.post('/', verifyToken, eventController.createEvent);

/**
 * @swagger
 * /api/v1/events/{id}:
 *   put:
 *     summary: Actualizar un evento existente
 *     tags: [Eventos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del evento
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateEventRequest'
 *     responses:
 *       200:
 *         description: Evento actualizado exitosamente
 *       400:
 *         description: Datos inválidos
 *       401:
 *         description: No autenticado
 *       404:
 *         description: Evento no encontrado
 *       500:
 *         description: Error del servidor
 */
router.put('/:id', verifyToken, eventController.updateEvent);

/**
 * @swagger
 * /api/v1/events/{id}:
 *   delete:
 *     summary: Eliminar un evento (solo admin)
 *     tags: [Eventos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID del evento
 *     responses:
 *       200:
 *         description: Evento eliminado exitosamente
 *       401:
 *         description: No autenticado
 *       403:
 *         description: Permiso denegado (no es admin)
 *       404:
 *         description: Evento no encontrado
 *       500:
 *         description: Error del servidor
 */
router.delete('/:id' ,verifyToken, checkRole('admin'), eventController.deleteEvent);

/**
 * ==========================================
 * CÓMO IMPLEMENTAR JWT EN ESTAS RUTAS
 * ==========================================
 * 
 * 1. HACER PÚBLICAS CON AUTH OPCIONAL (recomendado para listar):
 *    router.get('/', optionalAuth, eventController.getAllEvents);
 *    // En el controlador: if (req.user) { mostrar más detalles }
 * 
 * 2. CREAR EVENTO (solo usuarios autenticados):
 *    router.post('/', verifyToken, eventController.createEvent);
 * 
 * 3. CREAR EVENTO (solo admin y organizadores):
 *    router.post('/', verifyToken, checkRole('admin', 'organizer'), eventController.createEvent);
 * 
 * 4. EDITAR EVENTO (solo creador, admin u organizador):
 *    router.put('/:id', verifyToken, eventController.updateEvent);
 *    // En el controlador verificar: if (event.createdBy !== req.user.id && !['admin', 'organizer'].includes(req.user.role))
 * 
 * 5. ELIMINAR EVENTO (solo admin):
 *    router.delete('/:id', verifyToken, checkRole('admin'), eventController.deleteEvent);
 * 
 * EJEMPLO COMPLETO DE IMPLEMENTACIÓN:
 * 
 * // Rutas públicas
 * router.get('/', optionalAuth, eventController.getAllEvents);
 * router.get('/:id', optionalAuth, eventController.getEventById);
 * 
 * // Rutas protegidas
 * router.post('/', verifyToken, checkRole('admin', 'organizer'), eventController.createEvent);
 * router.put('/:id', verifyToken, eventController.updateEvent);
 * router.delete('/:id', verifyToken, checkRole('admin'), eventController.deleteEvent);
 * 
 * // Registro a eventos (requiere usuario y email verificado)
 * router.post('/:id/register', verifyToken, requireEmailVerification, eventController.registerToEvent);
 */

// TODO: Rutas adicionales - implementar en el controlador
// router.get('/category/:category', eventController.getEventsByCategory);
// router.get('/search', eventController.searchEvents);

module.exports = router;
