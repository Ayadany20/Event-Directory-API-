// src/services/event.service.js
const eventRepository = require('../repositories/event.repository');
const db = require('../models');
const { Op } = require('sequelize');

/**
 * ==========================================
 * EVENT SERVICE
 * ==========================================
 * Capa de lógica de negocio para eventos.
 * Responsabilidad: Validaciones, reglas de negocio, orquestación
 */

class EventService {
    
    /**
     * Obtener todos los eventos con filtros y paginación
     */
    async getAllEvents(filters) {
        const { 
            page = 1, 
            limit = 10, 
            categoryId, 
            search,
            status = 'published',
            startDate,
            endDate
        } = filters;

        const offset = (page - 1) * limit;
        const where = {};

        // Construir filtros
        if (categoryId) {
            where.categoryId = categoryId;
        }
        
        if (status) {
            where.status = status;
        }
        
        if (search) {
            where[Op.or] = [
                { title: { [Op.like]: `%${search}%` } },
                { description: { [Op.like]: `%${search}%` } }
            ];
        }
        
        if (startDate) {
            where.startDate = { [Op.gte]: new Date(startDate) };
        }
        
        if (endDate) {
            where.endDate = { [Op.lte]: new Date(endDate) };
        }

        // Incluir relaciones
        const include = [
            {
                model: db.Category,
                as: 'category',
                attributes: ['id', 'name', 'slug', 'color']
            },
            {
                model: db.User,
                as: 'creator',
                attributes: ['id', 'name', 'email']
            }
        ];

        // Opciones de query
        const queryOptions = {
            where,
            limit: parseInt(limit),
            offset: parseInt(offset),
            include,
            order: [['startDate', 'ASC']]
        };

        // Obtener eventos desde el repositorio
        const { count, rows: events } = await eventRepository.findAll(queryOptions);

        return {
            events,
            pagination: {
                total: count,
                page: parseInt(page),
                limit: parseInt(limit),
                totalPages: Math.ceil(count / limit)
            }
        };
    }

    /**
     * Obtener evento por ID
     */
    async getEventById(id) {
        const include = [
            {
                model: db.Category,
                as: 'category',
                attributes: ['id', 'name', 'slug', 'color', 'icon']
            },
            {
                model: db.User,
                as: 'creator',
                attributes: ['id', 'name', 'email']
            },
            {
                model: db.EventRegistration,
                as: 'registrations',
                attributes: ['id', 'attendeeName', 'attendeeEmail', 'isConfirmed']
            }
        ];

        const event = await eventRepository.findById(id, include);
        
        if (!event) {
            throw new Error('Evento no encontrado');
        }

        return event;
    }

    /**
     * Crear evento
     */
    async createEvent(eventData, userId) {
        // Validaciones de negocio
        if (!eventData.title || !eventData.description) {
            throw new Error('Título y descripción son requeridos');
        }

        // Campos obligatorios en el modelo
        if (!eventData.startDate) {
            throw new Error('startDate es requerido');
        }

        if (!eventData.endDate) {
            throw new Error('endDate es requerido');
        }

        if (!eventData.categoryId) {
            throw new Error('categoryId es requerido');
        }

        if (!eventData.location) {
            throw new Error('location es requerido');
        }

        // Parsear fechas y validar rango
        const start = new Date(eventData.startDate);
        const end = new Date(eventData.endDate);
        if (isNaN(start.getTime()) || isNaN(end.getTime())) {
            throw new Error('Formato de fecha inválido para startDate o endDate');
        }

        if (end < start) {
            throw new Error('endDate debe ser igual o posterior a startDate');
        }

        if (eventData.maxCapacity && eventData.maxCapacity < 1) {
            throw new Error('La capacidad máxima debe ser mayor a 0');
        }

        // Generar slug si no viene en el body
        const generateSlug = (text) => {
            return String(text)
                .toLowerCase()
                .trim()
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, '');
        };

        const slug = eventData.slug ? String(eventData.slug) : generateSlug(eventData.title);

        // Verificar que la categoría exista (evitar violación de FK en la BD)
        const category = await db.Category.findByPk(eventData.categoryId);
        if (!category) {
            throw new Error(`categoryId ${eventData.categoryId} no existe`);
        }

        // Verificar que el usuario creador exista
        const userExists = await db.User.findByPk(userId);
        if (!userExists) {
            throw new Error(`Usuario creado por (createdBy) id ${userId} no existe`);
        }

        // Preparar datos para guardar
        const dataToCreate = {
            ...eventData,
            startDate: start,
            endDate: end,
            slug,
            createdBy: userId,
            availableSpots: eventData.maxCapacity || 100
        };

        // Crear en repositorio
        return await eventRepository.create(dataToCreate);
    }

    /**
     * Actualizar evento
     */
    async updateEvent(id, updateData, userId, userRole) {
        // Buscar evento
        const event = await eventRepository.findById(id);
        
        if (!event) {
            throw new Error('Evento no encontrado');
        }

        // Validar permisos
        if (event.createdBy !== userId && userRole !== 'admin') {
            throw new Error('No tienes permiso para editar este evento');
        }

        // Validaciones de negocio
        if (updateData.maxCapacity) {
            const occupiedSpots = event.maxCapacity - event.availableSpots;
            
            if (updateData.maxCapacity < occupiedSpots) {
                throw new Error(`No puedes reducir la capacidad por debajo de ${occupiedSpots} (espacios ocupados)`);
            }

            // Recalcular espacios disponibles
            updateData.availableSpots = updateData.maxCapacity - occupiedSpots;
        }

        // Actualizar
        return await eventRepository.update(event, updateData);
    }

    /**
     * Eliminar evento
     */
    async deleteEvent(id, userId, userRole) {
        const event = await eventRepository.findById(id);
        
        if (!event) {
            throw new Error('Evento no encontrado');
        }

        // Validar permisos
        if (event.createdBy !== userId && userRole !== 'admin') {
            throw new Error('No tienes permiso para eliminar este evento');
        }

        // Verificar si tiene registros
        const registrationsCount = await db.EventRegistration.count({ 
            where: { eventId: id } 
        });

        if (registrationsCount > 0 && userRole !== 'admin') {
            throw new Error('No puedes eliminar un evento con registros. Contacta al administrador.');
        }

        return await eventRepository.delete(event);
    }

    /**
     * Buscar eventos por categoría
     */
    async getEventsByCategory(categoryId, options = {}) {
        const { page = 1, limit = 10 } = options;
        const offset = (page - 1) * limit;

        return await eventRepository.findByCategory(categoryId, {
            limit: parseInt(limit),
            offset: parseInt(offset),
            order: [['startDate', 'ASC']]
        });
    }

    /**
     * Buscar eventos creados por un usuario
     */
    async getEventsByCreator(userId, options = {}) {
        const { page = 1, limit = 10, status } = options;
        const offset = (page - 1) * limit;

        const queryOptions = {
            limit: parseInt(limit),
            offset: parseInt(offset),
            order: [['createdAt', 'DESC']],
            include: [
                {
                    model: db.Category,
                    as: 'category',
                    attributes: ['id', 'name', 'slug']
                }
            ]
        };

        if (status) {
            queryOptions.where = { status };
        }

        return await eventRepository.findByCreator(userId, queryOptions);
    }
}

module.exports = new EventService();
