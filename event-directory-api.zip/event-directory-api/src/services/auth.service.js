// src/services/auth.service.js
const bcrypt = require('bcryptjs');
const userRepository = require('../repositories/user.repository');
const { generateTokenPair } = require('../utils/jwt.util');

/**
 * ==========================================
 * AUTH SERVICE
 * ==========================================
 * Capa de lógica de negocio para autenticación.
 * Responsabilidad: Validaciones, reglas de negocio, generación de tokens
 */

class AuthService {
    
    /**
     * Registrar nuevo usuario
     */
    async register(userData) {
        const { name, email, password, phone, role } = userData;

        // Validaciones básicas
        if (!name || !email || !password) {
            throw new Error('Nombre, email y contraseña son requeridos');
        }

        // Validar formato de email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            throw new Error('Formato de email inválido');
        }

        // Validar longitud de contraseña
        if (password.length < 6) {
            throw new Error('La contraseña debe tener al menos 6 caracteres');
        }

        // Verificar si el email ya existe
        const existingUser = await userRepository.findByEmail(email);
        if (existingUser) {
            throw new Error('El email ya está registrado');
        }

        // Hash de la contraseña
        const hashedPassword = await bcrypt.hash(password, 10);

        // Crear usuario
        const user = await userRepository.create({
            name,
            email,
            password: hashedPassword,
            phone,
            role: role || 'user',
            isActive: true,
            isEmailVerified: false
        });

        // Generar tokens JWT
        const tokens = generateTokenPair({
            id: user.id,
            email: user.email,
            role: user.role,
            name: user.name
        });

        // Enviar email de bienvenida (sin bloquear el registro)
        const emailService = require('./email.service');
        emailService.sendWelcomeEmail(user).catch(err => {
            console.error('⚠️ Error al enviar email de bienvenida:', err.message);
            // No fallar el registro si el email falla
        });

        // Preparar respuesta (sin contraseña)
        const userResponse = user.toJSON();
        delete userResponse.password;

        return {
            user: userResponse,
            ...tokens
        };
    }

    /**
     * Iniciar sesión
     */
    async login(credentials) {
        const { email, password } = credentials;

        // Validaciones
        if (!email || !password) {
            throw new Error('Email y contraseña son requeridos');
        }

        // Buscar usuario (incluir password para verificar)
        const user = await userRepository.findByEmail(email, true);

        if (!user) {
            throw new Error('Credenciales inválidas');
        }

        // Verificar contraseña
        const isPasswordValid = await bcrypt.compare(password, user.password);

        if (!isPasswordValid) {
            throw new Error('Credenciales inválidas');
        }

        // Verificar si el usuario está activo
        if (!user.isActive) {
            throw new Error('Usuario inactivo. Contacta al administrador.');
        }

        // Actualizar último login
        await userRepository.update(user, { lastLogin: new Date() });

        // Generar tokens JWT
        const tokens = generateTokenPair({
            id: user.id,
            email: user.email,
            role: user.role,
            name: user.name
        });

        // Preparar respuesta
        const userResponse = user.toJSON();
        delete userResponse.password;

        return {
            user: userResponse,
            ...tokens
        };
    }

    /**
     * Obtener perfil del usuario
     */
    async getProfile(userId) {
        const user = await userRepository.findById(userId);

        if (!user) {
            throw new Error('Usuario no encontrado');
        }

        return user;
    }

    /**
     * Actualizar perfil del usuario
     */
    async updateProfile(userId, updateData) {
        const user = await userRepository.findById(userId, false);

        if (!user) {
            throw new Error('Usuario no encontrado');
        }

        // Solo permitir actualizar ciertos campos
        const allowedFields = ['name', 'phone'];
        const updates = {};

        allowedFields.forEach(field => {
            if (updateData[field] !== undefined) {
                updates[field] = updateData[field];
            }
        });

        const updatedUser = await userRepository.update(user, updates);

        // Remover password de la respuesta
        const userResponse = updatedUser.toJSON();
        delete userResponse.password;

        return userResponse;
    }

    /**
     * Cambiar contraseña
     */
    async changePassword(userId, currentPassword, newPassword) {
        // Buscar usuario con password
        const user = await userRepository.findById(userId, false);

        if (!user) {
            throw new Error('Usuario no encontrado');
        }

        // Obtener usuario completo con password
        const userWithPassword = await userRepository.findOne({ id: userId }, true);

        // Verificar contraseña actual
        const isPasswordValid = await bcrypt.compare(currentPassword, userWithPassword.password);

        if (!isPasswordValid) {
            throw new Error('Contraseña actual incorrecta');
        }

        // Validar nueva contraseña
        if (newPassword.length < 6) {
            throw new Error('La nueva contraseña debe tener al menos 6 caracteres');
        }

        // Hash de la nueva contraseña
        const hashedPassword = await bcrypt.hash(newPassword, 10);

        // Actualizar
        await userRepository.update(user, { password: hashedPassword });

        return true;
    }

    /**
     * Solicitar recuperación de contraseña
     */
    async forgotPassword(email) {
        const user = await userRepository.findByEmail(email);

        // Por seguridad, no revelar si el email existe o no
        if (!user) {
            return {
                message: 'Si el email existe, recibirás instrucciones para restablecer tu contraseña'
            };
        }

        // TODO: Generar token de recuperación y enviar email

        return {
            message: 'Si el email existe, recibirás instrucciones para restablecer tu contraseña'
        };
    }

    /**
     * Restablecer contraseña con token
     */
    async resetPassword(token, newPassword) {
        // TODO: Verificar token de recuperación

        // Validar nueva contraseña
        if (newPassword.length < 6) {
            throw new Error('La contraseña debe tener al menos 6 caracteres');
        }

        // TODO: Actualizar contraseña del usuario asociado al token

        return {
            message: 'Contraseña restablecida exitosamente'
        };
    }
}

module.exports = new AuthService();
