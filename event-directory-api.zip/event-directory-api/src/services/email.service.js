// src/services/email.service.js
const nodemailer = require('nodemailer');
const config = require('../config/server.config');

/**
 * ==========================================
 * EMAIL SERVICE
 * ==========================================
 * Servicio para envío de correos electrónicos
 * Usa Nodemailer con configuración de Gmail
 */

class EmailService {
    constructor() {
        // Configurar transporter de nodemailer
        this.transporter = nodemailer.createTransport({
            service: config.email.service,
            auth: {
                user: config.email.user,
                pass: config.email.password
            }
        });
    }

    /**
     * Verificar conexión con el servidor de email
     */
    async verifyConnection() {
        try {
            await this.transporter.verify();
            console.log('✅ Servidor de email conectado correctamente');
            return true;
        } catch (error) {
            console.error('❌ Error al conectar con el servidor de email:', error.message);
            return false;
        }
    }

    /**
     * Enviar email genérico
     */
    async sendEmail({ to, subject, text, html }) {
        try {
            // Validaciones
            if (!to) {
                throw new Error('El destinatario (to) es requerido');
            }

            if (!subject) {
                throw new Error('El asunto (subject) es requerido');
            }

            if (!text && !html) {
                throw new Error('Debe proporcionar contenido (text o html)');
            }

            // Opciones del email
            const mailOptions = {
                from: `"${config.email.fromName}" <${config.email.from}>`,
                to,
                subject,
                text,
                html: html || text // Si no hay HTML, usa texto plano
            };

            // Enviar email
            const info = await this.transporter.sendMail(mailOptions);

            console.log(`📧 Email enviado a ${to}: ${info.messageId}`);

            return {
                success: true,
                messageId: info.messageId,
                to,
                subject
            };
        } catch (error) {
            console.error('❌ Error al enviar email:', error.message);
            throw new Error(`Error al enviar email: ${error.message}`);
        }
    }

    /**
     * Enviar email de bienvenida
     */
    async sendWelcomeEmail(user) {
        const subject = '¡Bienvenido a Event Directory! 🎉';
        
        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                    .button { display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
                    .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🎉 ¡Bienvenido!</h1>
                    </div>
                    <div class="content">
                        <h2>Hola ${user.name},</h2>
                        <p>¡Gracias por registrarte en <strong>Event Directory</strong>!</p>
                        <p>Tu cuenta ha sido creada exitosamente. Ahora puedes:</p>
                        <ul>
                            <li>✅ Explorar eventos increíbles</li>
                            <li>✅ Crear tus propios eventos</li>
                            <li>✅ Registrarte en eventos</li>
                            <li>✅ Conectar con otros usuarios</li>
                        </ul>
                        <p><strong>Email:</strong> ${user.email}</p>
                        <p><strong>Rol:</strong> ${user.role === 'user' ? 'Usuario' : user.role === 'organizer' ? 'Organizador' : 'Administrador'}</p>
                        <a href="http://localhost:3000/api/v1/events" class="button">Ver Eventos</a>
                    </div>
                    <div class="footer">
                        <p>Event Directory API © 2025</p>
                        <p>Si no solicitaste esta cuenta, por favor ignora este correo.</p>
                    </div>
                </div>
            </body>
            </html>
        `;

        return await this.sendEmail({
            to: user.email,
            subject,
            html
        });
    }

    /**
     * Enviar email de confirmación de registro a evento
     */
    async sendEventRegistrationEmail(user, event) {
        const subject = `Registro confirmado: ${event.title} ✅`;
        
        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: #10b981; color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                    .event-details { background: white; padding: 20px; border-left: 4px solid #10b981; margin: 20px 0; }
                    .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>✅ ¡Registro Confirmado!</h1>
                    </div>
                    <div class="content">
                        <h2>Hola ${user.name},</h2>
                        <p>Tu registro al evento ha sido confirmado exitosamente.</p>
                        
                        <div class="event-details">
                            <h3>📅 ${event.title}</h3>
                            <p><strong>Descripción:</strong> ${event.description}</p>
                            <p><strong>Fecha:</strong> ${new Date(event.startDate).toLocaleDateString('es-MX', { 
                                weekday: 'long', 
                                year: 'numeric', 
                                month: 'long', 
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                            })}</p>
                            <p><strong>Ubicación:</strong> ${event.location || 'Por definir'}</p>
                        </div>

                        <p>Te esperamos en el evento. ¡No faltes!</p>
                    </div>
                    <div class="footer">
                        <p>Event Directory API © 2025</p>
                    </div>
                </div>
            </body>
            </html>
        `;

        return await this.sendEmail({
            to: user.email,
            subject,
            html
        });
    }

    /**
     * Enviar email de recuperación de contraseña
     */
    async sendPasswordResetEmail(user, resetToken) {
        const resetUrl = `http://localhost:3000/api/v1/auth/reset-password?token=${resetToken}`;
        const subject = 'Recuperación de contraseña 🔐';
        
        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: #ef4444; color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                    .button { display: inline-block; padding: 12px 30px; background: #ef4444; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
                    .warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; }
                    .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🔐 Recuperación de Contraseña</h1>
                    </div>
                    <div class="content">
                        <h2>Hola ${user.name},</h2>
                        <p>Recibimos una solicitud para restablecer tu contraseña.</p>
                        
                        <p>Haz clic en el siguiente botón para crear una nueva contraseña:</p>
                        <a href="${resetUrl}" class="button">Restablecer Contraseña</a>
                        
                        <p style="margin-top: 20px; font-size: 12px; color: #666;">
                            O copia y pega este enlace en tu navegador:<br>
                            <code>${resetUrl}</code>
                        </p>

                        <div class="warning">
                            <strong>⚠️ Importante:</strong><br>
                            Este enlace expirará en <strong>1 hora</strong>.<br>
                            Si no solicitaste este cambio, ignora este correo.
                        </div>
                    </div>
                    <div class="footer">
                        <p>Event Directory API © 2025</p>
                        <p>Por tu seguridad, nunca compartas este correo.</p>
                    </div>
                </div>
            </body>
            </html>
        `;

        return await this.sendEmail({
            to: user.email,
            subject,
            html
        });
    }

    /**
     * Enviar notificación al creador del evento
     */
    async sendEventCreatedNotification(creator, event) {
        const subject = `✅ Tu evento "${event.title}" ha sido publicado`;
        
        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: #8b5cf6; color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                    .stats { display: flex; justify-content: space-around; margin: 20px 0; }
                    .stat { text-align: center; background: white; padding: 15px; border-radius: 5px; }
                    .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🎉 Evento Publicado</h1>
                    </div>
                    <div class="content">
                        <h2>Hola ${creator.name},</h2>
                        <p>Tu evento <strong>"${event.title}"</strong> ha sido publicado exitosamente.</p>
                        
                        <div class="stats">
                            <div class="stat">
                                <h3>${event.maxCapacity}</h3>
                                <p>Capacidad máxima</p>
                            </div>
                            <div class="stat">
                                <h3>${event.availableSpots}</h3>
                                <p>Lugares disponibles</p>
                            </div>
                        </div>

                        <p><strong>Estado:</strong> ${event.status}</p>
                        <p><strong>Fecha de inicio:</strong> ${new Date(event.startDate).toLocaleDateString('es-MX')}</p>
                        
                        <p>Los usuarios ya pueden ver y registrarse en tu evento.</p>
                    </div>
                    <div class="footer">
                        <p>Event Directory API © 2025</p>
                    </div>
                </div>
            </body>
            </html>
        `;

        return await this.sendEmail({
            to: creator.email,
            subject,
            html
        });
    }
}

module.exports = new EmailService();