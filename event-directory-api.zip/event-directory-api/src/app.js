// src/app.js
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const serverConfig = require('./config/server.config');
const errorHandler = require('./middlewares/errorHandler');
const notFound = require('./middlewares/notFound');

const app = express();

// ==================== SEGURIDAD ====================
app.use(helmet());
app.use(cors({
    origin: serverConfig.cors.origin,
    credentials: true
}));

// ==================== MIDDLEWARES ====================
if (serverConfig.nodeEnv === 'development') {
    app.use(morgan('dev'));
}

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ==================== VARIABLES GLOBALES ====================
// Para compartir estado de BD
app.locals.dbConnected = false;
app.locals.dbError = null;

// ==================== RUTAS ====================
// Todas las rutas están centralizadas en routes/index.js
app.use(serverConfig.app.apiPrefix, require('./routes'));
// ==================== SWAGGER/OPENAPI ====================
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('../swagger');
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, {
    swaggerOptions: {
        persistAuthorization: true,
        displayOperationId: true
    }
}));


// ==================== MANEJO DE ERRORES ====================
app.use(notFound);
app.use(errorHandler);

module.exports = app;
