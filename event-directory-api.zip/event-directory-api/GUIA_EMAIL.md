# 📧 GUÍA DE USO DEL SERVICIO DE EMAIL

## 📋 Configuración

Asegúrate de tener configuradas las variables de entorno en tu archivo `.env`:

```env
# Configuración de Email (Gmail)
EMAIL_SERVICE=gmail
EMAIL_USER=tu.correo@gmail.com
EMAIL_PASS=tu_password_de_aplicacion_gmail
EMAIL_FROM=tu.correo@gmail.com
EMAIL_FROM_NAME=Event Directory
```

### 🔑 Cómo obtener la contraseña de aplicación de Gmail

1. Ve a tu cuenta de Google: https://myaccount.google.com/
2. Seguridad → Verificación en 2 pasos (actívala si no está activa)
3. Contraseñas de aplicaciones
4. Genera una nueva contraseña para "Correo"
5. Copia la contraseña de 16 caracteres
6. Pégala en `EMAIL_PASS` (sin espacios)

---

## 🚀 ENDPOINTS DISPONIBLES

### 1. Verificar conexión del servidor de email

**Endpoint:** `GET /api/v1/email/verify`  
**Auth:** ✅ Requerido (Admin)  
**Descripción:** Verifica que la configuración de email sea correcta

```bash
curl -X GET http://localhost:3000/api/v1/email/verify \
  -H "Authorization: Bearer TU_TOKEN_ADMIN"
```

**Respuesta exitosa:**
```json
{
  "success": true,
  "message": "Conexión con el servidor de email verificada exitosamente",
  "data": {
    "service": "gmail",
    "user": "tu.correo@gmail.com",
    "from": "tu.correo@gmail.com"
  }
}
```

---

### 2. Enviar email de prueba

**Endpoint:** `POST /api/v1/email/test`  
**Auth:** ✅ Requerido (Admin)  
**Descripción:** Envía un email de prueba para verificar funcionamiento

```bash
curl -X POST http://localhost:3000/api/v1/email/test \
  -H "Authorization: Bearer TU_TOKEN_ADMIN" \
  -H "Content-Type: application/json" \
  -d '{
    "to": "destinatario@example.com"
  }'
```

**Body:**
```json
{
  "to": "destinatario@example.com"
}
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Email de prueba enviado exitosamente",
  "data": {
    "success": true,
    "messageId": "<abc123@gmail.com>",
    "to": "destinatario@example.com",
    "subject": "📧 Email de Prueba - Event Directory API"
  }
}
```

---

### 3. Enviar email genérico

**Endpoint:** `POST /api/v1/email/send`  
**Auth:** ✅ Requerido (Admin, Organizer)  
**Descripción:** Envía un email personalizado

```bash
curl -X POST http://localhost:3000/api/v1/email/send \
  -H "Authorization: Bearer TU_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "to": "usuario@example.com",
    "subject": "¡Hola desde Event Directory!",
    "text": "Este es el contenido en texto plano",
    "html": "<h1>Hola</h1><p>Este es el contenido en HTML</p>"
  }'
```

**Body:**
```json
{
  "to": "usuario@example.com",
  "subject": "Asunto del correo",
  "text": "Contenido en texto plano (opcional si tienes html)",
  "html": "<h1>Contenido HTML</h1><p>Con formato bonito</p>"
}
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Email enviado exitosamente",
  "data": {
    "success": true,
    "messageId": "<xyz789@gmail.com>",
    "to": "usuario@example.com",
    "subject": "¡Hola desde Event Directory!"
  }
}
```

---

### 4. Enviar email de bienvenida

**Endpoint:** `POST /api/v1/email/welcome`  
**Auth:** ✅ Requerido (Admin)  
**Descripción:** Envía un email de bienvenida con diseño profesional

```bash
curl -X POST http://localhost:3000/api/v1/email/welcome \
  -H "Authorization: Bearer TU_TOKEN_ADMIN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Juan Pérez",
    "email": "juan@example.com",
    "role": "user"
  }'
```

**Body:**
```json
{
  "name": "Juan Pérez",
  "email": "juan@example.com",
  "role": "user"
}
```

**Email enviado:**
- ✅ Diseño profesional con CSS
- ✅ Saludo personalizado
- ✅ Información de la cuenta
- ✅ Lista de funcionalidades
- ✅ Botón de acción

---

### 5. Enviar confirmación de evento

**Endpoint:** `POST /api/v1/email/event-confirmation`  
**Auth:** ✅ Requerido (Admin, Organizer)  
**Descripción:** Envía confirmación de registro a evento

```bash
curl -X POST http://localhost:3000/api/v1/email/event-confirmation \
  -H "Authorization: Bearer TU_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "userName": "María García",
    "userEmail": "maria@example.com",
    "eventTitle": "Conferencia Tech 2025",
    "eventDescription": "Evento de tecnología e innovación",
    "eventStartDate": "2025-06-15T10:00:00",
    "eventLocation": "Centro de Convenciones"
  }'
```

**Body:**
```json
{
  "userName": "María García",
  "userEmail": "maria@example.com",
  "eventTitle": "Conferencia Tech 2025",
  "eventDescription": "Evento de tecnología e innovación",
  "eventStartDate": "2025-06-15T10:00:00",
  "eventLocation": "Centro de Convenciones"
}
```

---

## 🎨 PLANTILLAS DE EMAIL INCLUIDAS

### 1. Email de Bienvenida
- Diseño con gradiente morado
- Saludo personalizado
- Lista de funcionalidades
- Información de cuenta
- Botón call-to-action

### 2. Email de Confirmación de Evento
- Diseño verde (éxito)
- Detalles del evento
- Fecha y hora formateada
- Ubicación del evento
- Mensaje de confirmación

### 3. Email de Recuperación de Contraseña
- Diseño rojo (alerta)
- Token de recuperación
- Link de restablecimiento
- Advertencia de expiración (1 hora)
- Nota de seguridad

### 4. Email de Notificación de Evento Creado
- Diseño morado
- Confirmación de publicación
- Estadísticas del evento
- Estado y capacidad
- Información para el creador

---

## 💡 USO PROGRAMÁTICO

### Desde otros servicios o controladores

```javascript
const emailService = require('../services/email.service');

// Enviar email genérico
await emailService.sendEmail({
  to: 'usuario@example.com',
  subject: 'Asunto',
  html: '<h1>Contenido</h1>'
});

// Enviar email de bienvenida
await emailService.sendWelcomeEmail({
  name: 'Juan',
  email: 'juan@example.com',
  role: 'user'
});

// Enviar confirmación de evento
await emailService.sendEventRegistrationEmail(user, event);

// Enviar recuperación de contraseña
await emailService.sendPasswordResetEmail(user, resetToken);

// Notificar creación de evento
await emailService.sendEventCreatedNotification(creator, event);
```

---

## 🔧 INTEGRACIÓN CON REGISTRO

Para enviar email automáticamente al registrar un usuario:

```javascript
// En auth.service.js - método register()
const user = await userRepository.create({...});

// Enviar email de bienvenida (sin bloquear el registro)
emailService.sendWelcomeEmail(user).catch(err => {
  console.error('Error al enviar email de bienvenida:', err);
});

return { user, ...tokens };
```

---

## 🐛 SOLUCIÓN DE PROBLEMAS

### Error: "Invalid login"
- ✅ Verifica que EMAIL_USER y EMAIL_PASS sean correctos
- ✅ Usa contraseña de aplicación, NO tu contraseña normal
- ✅ Activa verificación en 2 pasos en Google

### Error: "Connection timeout"
- ✅ Verifica tu conexión a internet
- ✅ Verifica que el firewall no bloquee el puerto 587
- ✅ Intenta cambiar `EMAIL_PORT` a 465 y `EMAIL_SECURE=true`

### Email no llega
- ✅ Revisa la carpeta de spam
- ✅ Verifica que el email destino sea válido
- ✅ Revisa los logs del servidor

### Error: "self signed certificate"
- ✅ Agrega a la configuración: `tls: { rejectUnauthorized: false }`

---

## 📊 CÓDIGOS DE RESPUESTA

| Código | Significado |
|--------|-------------|
| 200 | Email enviado exitosamente |
| 400 | Datos inválidos (falta to, subject, etc.) |
| 401 | No autenticado (falta token) |
| 403 | No autorizado (no tiene rol admin/organizer) |
| 500 | Error del servidor o del servicio de email |

---

## 🔒 SEGURIDAD

**✅ Mejores prácticas:**
- Nunca expongas EMAIL_PASS en código
- Usa contraseñas de aplicación, no contraseñas normales
- Limita quién puede enviar emails (solo admin/organizer)
- Valida emails antes de enviar
- Implementa rate limiting para prevenir spam
- Registra todos los envíos en logs

**❌ NO HACER:**
- No permitas envío sin autenticación
- No permitas HTML sin sanitizar
- No expongas credenciales en respuestas
- No envíes emails masivos sin control

---

## 📚 RECURSOS

- [Nodemailer Documentation](https://nodemailer.com/)
- [Gmail App Passwords](https://support.google.com/accounts/answer/185833)
- [HTML Email Best Practices](https://www.emailonacid.com/blog/)

---

**✨ ¡Listo para enviar emails profesionales!**
