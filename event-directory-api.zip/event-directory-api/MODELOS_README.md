# 📋 Modelos Implementados - Event Directory API

## ✅ Modelos Creados

### 1. **User Model** (`user.model.js`)
Usuario del sistema con roles y verificación de email.

**Campos principales:**
- id, name, email, password, phone
- role: `user`, `admin`, `organizer`
- isActive, isEmailVerified, emailVerifiedAt, lastLogin

---

### 2. **Category Model** (`category.model.js`)
Categorías para clasificar eventos.

**Campos principales:**
- id, name, description, slug
- color (código hexadecimal)
- icon, isActive

---

### 3. **Event Model** (`event.model.js`)
Eventos con gestión de cupo y multimedia.

**Campos principales:**
- Información básica: title, description, location, dates
- **Gestión de cupo:**
  - `maxCapacity`: Cupo máximo
  - `availableSpots`: Espacios disponibles
  - `occupiedSpots`: Calculado automáticamente
  - `occupancyPercentage`: % de ocupación
  - `isFull`: Indica si está lleno
- **Multimedia:**
  - `imageUrl`: Imagen principal
  - `flyerUrl`: **Flyer del evento** ✨
  - `galleryUrls`: Galería de imágenes
- **Estado:** draft, published, cancelled, completed, **sold_out**
- Precio, organizador, tags, slug

**Hooks automáticos:**
- Cambia a `sold_out` cuando `availableSpots = 0`
- Vuelve a `published` si se liberan espacios

---

### 4. **Event Registration Model** (`eventRegistration.model.js`)
Registro de asistentes a eventos con confirmación por email.

**Campos principales:**
- **Datos del asistente:**
  - attendeeName, attendeeEmail, attendeePhone
  - attendeeDocument, numberOfGuests
  - specialRequirements
- **Confirmación:**
  - confirmationToken
  - confirmationTokenExpiry
  - isConfirmed, confirmationDate
- **Estado:** pending, confirmed, cancelled, attended, no_show
- **Check-in:**
  - qrCode
  - checkInDate, isCheckedIn
- **Pago:**
  - paymentStatus, paymentReference, amountPaid
- **Notificaciones:**
  - emailSent, reminderSent

---

### 5. **Confirmation Token Model** (`confirmationToken.model.js`)
Tokens para confirmación de asistencia y verificación de email.

**Campos principales:**
- token (único)
- type: `event_registration`, `email_verification`, `password_reset`
- email, expiresAt
- isUsed, usedAt
- attempts, maxAttempts
- **Campo virtual:** `isExpired` (calcula si expiró)

---

## 🔗 Relaciones Entre Modelos

```
User (1) ──── (N) Event (creador)
User (1) ──── (N) EventRegistration
User (1) ──── (N) ConfirmationToken

Category (1) ──── (N) Event

Event (1) ──── (N) EventRegistration
EventRegistration (1) ──── (N) ConfirmationToken
```

---

## 🚀 Uso en Server.js

El archivo `server.js` ahora:
1. ✅ Conecta a la base de datos
2. ✅ Sincroniza todos los modelos automáticamente
3. ✅ Crea/actualiza las tablas
4. ✅ Muestra el estado de la conexión

---

## 📝 Próximos Pasos Sugeridos

1. **Crear seeders** para datos iniciales (categorías, usuario admin)
2. **Implementar repositorios** para acceso a datos
3. **Crear servicios** para lógica de negocio
4. **Implementar email service** para envío de confirmaciones
5. **Crear controladores** para las rutas de la API

---

## 🎯 Características Destacadas

✅ Gestión automática de cupo de eventos
✅ Sistema de confirmación por email con tokens
✅ QR codes para check-in
✅ Campos virtuales calculados automáticamente
✅ Validaciones exhaustivas
✅ Índices para optimizar consultas
✅ Hooks para automatizar cambios de estado
✅ Soporte para eventos gratuitos y de pago
✅ Lista de espera cuando se llena el evento
✅ Múltiples URLs para imágenes y flyers
