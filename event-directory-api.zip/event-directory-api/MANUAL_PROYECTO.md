# 📚 MANUAL DEL PROYECTO - Event Directory API

> **Sistema de gestión de eventos con autenticación JWT y arquitectura en capas**

**Versión:** 1.0.0  
**Framework:** Express.js v5 + Sequelize ORM v6  
**Base de datos:** SQL Server 2019+  
**Patrón arquitectónico:** Controller-Service-Repository (CSR)  
**Autenticación:** JWT (JSON Web Tokens) con Bearer scheme  
**Lenguaje:** JavaScript (Node.js v18+)

---

## 📑 ÍNDICE

1. [Introducción y conceptos básicos](#1-introducción-y-conceptos-básicos)
2. [Tecnologías y dependencias](#2-tecnologías-y-dependencias)
3. [Estructura del proyecto](#3-estructura-del-proyecto)
4. [Configuración inicial](#4-configuración-inicial)
5. [Arquitectura CSR explicada](#5-arquitectura-csr-explicada)
6. [Modelos y relaciones de base de datos](#6-modelos-y-relaciones-de-base-de-datos)
7. [Autenticación JWT](#7-autenticación-jwt)
8. [Middlewares y su funcionamiento](#8-middlewares-y-su-funcionamiento)
9. [Repositorios - Capa de datos](#9-repositorios---capa-de-datos)
10. [Servicios - Lógica de negocio](#10-servicios---lógica-de-negocio)
11. [Controladores - Capa HTTP](#11-controladores---capa-http)
12. [Endpoints y API REST](#12-endpoints-y-api-rest)
13. [Comandos útiles](#13-comandos-útiles)
14. [Solución de problemas](#14-solución-de-problemas)
15. [Mejores prácticas](#15-mejores-prácticas)

---

## 1. INTRODUCCIÓN Y CONCEPTOS BÁSICOS

### 🎯 ¿Qué es una API REST?

**REST** (Representational State Transfer) es un estilo arquitectónico para diseñar APIs web que usa los métodos HTTP estándar:

| Método HTTP | Propósito | Ejemplo |
|-------------|-----------|---------|
| `GET` | Obtener recursos | Listar eventos, ver detalles |
| `POST` | Crear recursos | Registrar usuario, crear evento |
| `PUT` | Actualizar recursos completos | Actualizar evento completo |
| `PATCH` | Actualizar parcialmente | Actualizar solo título del evento |
| `DELETE` | Eliminar recursos | Eliminar evento |

### 🔄 Ciclo de vida de una petición HTTP

```
1. Cliente envía petición HTTP
   └─→ GET http://localhost:3000/api/v1/events

2. Servidor Express recibe la petición
   └─→ Router identifica la ruta

3. Middleware de autenticación (si aplica)
   └─→ Verifica token JWT

4. Controlador procesa la petición
   └─→ Valida datos de entrada

5. Servicio aplica lógica de negocio
   └─→ Validaciones, permisos, reglas

6. Repositorio consulta la base de datos
   └─→ Query SQL a través de Sequelize

7. Respuesta viaja de vuelta
   └─→ Repository → Service → Controller → Cliente

8. Cliente recibe respuesta JSON
   └─→ { success: true, data: [...] }
```

### 💡 ¿Por qué usar arquitectura en capas?

**Problema sin capas:**
```javascript
// ❌ TODO EN EL CONTROLADOR (MAL)
router.get('/events', async (req, res) => {
    // Validación mezclada con lógica
    if (!req.body.title || req.body.title.length < 3) {
        return res.status(400).json({ error: 'Título muy corto' });
    }
    
    // Query directa en el controlador
    const events = await db.Event.findAll({
        where: { status: 'published' },
        include: [{ model: db.Category }]
    });
    
    // Lógica de negocio en el controlador
    const filteredEvents = events.filter(e => e.maxCapacity > 10);
    
    res.json(filteredEvents);
});
```

**Solución con capas:**
```javascript
// ✅ SEPARADO EN CAPAS (BIEN)

// Controller: Solo maneja HTTP
router.get('/events', eventController.getAllEvents);

// Service: Lógica de negocio
const getAllEvents = (filters) => {
    // Validaciones y reglas de negocio
    const events = await eventRepository.findAll(filters);
    return events.filter(e => e.maxCapacity > 10);
};

// Repository: Solo acceso a datos
const findAll = (filters) => {
    return db.Event.findAll({
        where: filters,
        include: [{ model: db.Category }]
    });
};
```

**Beneficios:**
- ✅ **Reutilización**: El repository puede usarse en múltiples servicios
- ✅ **Testeo**: Cada capa se prueba independientemente
- ✅ **Mantenibilidad**: Cambios en BD solo afectan repositories
- ✅ **Escalabilidad**: Fácil agregar nuevas funcionalidades
- ✅ **Claridad**: Cada archivo tiene un propósito claro

---

## 2. TECNOLOGÍAS Y DEPENDENCIAS

### 📦 Instalación completa del proyecto

```bash
# 1. Inicializar proyecto Node.js
npm init -y

# 2. Instalar todas las dependencias de producción
npm install express dotenv sequelize tedious bcryptjs jsonwebtoken cors helmet morgan

# 3. Instalar dependencias de desarrollo
npm install --save-dev nodemon

# 4. Verificar instalación
npm list --depth=0
```

### 🔧 Dependencias principales (explicadas)

| Paquete | Versión | Propósito | ¿Por qué lo usamos? |
|---------|---------|-----------|---------------------|
| `express` | ^5.1.0 | Framework web | Crea servidor HTTP, maneja rutas, middleware |
| `sequelize` | ^6.37.7 | ORM | Abstrae SQL, permite escribir queries en JavaScript |
| `tedious` | ^18.6.1 | Driver SQL Server | Conecta Node.js con SQL Server |
| `dotenv` | ^16.4.7 | Variables de entorno | Carga variables desde archivo `.env` |
| `bcryptjs` | ^2.4.3 | Hash de contraseñas | Encripta contraseñas (nunca guardar en texto plano) |
| `jsonwebtoken` | ^9.0.2 | Autenticación JWT | Genera y verifica tokens de autenticación |
| `cors` | ^2.8.5 | Cross-Origin Resource Sharing | Permite peticiones desde otros dominios |
| `helmet` | ^8.0.0 | Seguridad HTTP | Protege contra vulnerabilidades comunes |
| `morgan` | ^1.10.0 | Logger HTTP | Registra todas las peticiones HTTP |
| `nodemon` | ^3.1.7 | Auto-reload | Reinicia servidor automáticamente al guardar |

### 📚 ¿Qué hace cada tecnología?

#### Express.js
```javascript
// Crea servidor web y define rutas
const express = require('express');
const app = express();

app.get('/eventos', (req, res) => {
    res.json({ mensaje: 'Lista de eventos' });
});

app.listen(3000);
```

#### Sequelize ORM
```javascript
// En lugar de escribir SQL puro:
// SELECT * FROM events WHERE status = 'published'

// Escribes JavaScript:
const events = await Event.findAll({
    where: { status: 'published' }
});
```

#### Bcrypt
```javascript
// Hash de contraseña (encriptación irreversible)
const hash = await bcrypt.hash('MiPassword123', 10);
// Resultado: $2b$10$N9qo8uLOickgx2ZMRZoMye...

// Verificar contraseña
const esValida = await bcrypt.compare('MiPassword123', hash);
// true o false
```

#### JWT (JSON Web Token)
```javascript
// Generar token
const token = jwt.sign(
    { userId: 1, email: 'user@example.com' },
    'SECRET_KEY',
    { expiresIn: '24h' }
);

// Verificar token
const payload = jwt.verify(token, 'SECRET_KEY');
// { userId: 1, email: 'user@example.com', iat: ..., exp: ... }
```

### 🎓 Conceptos importantes

**ORM (Object-Relational Mapping):**
- Convierte tablas de BD en objetos JavaScript
- Abstrae SQL para escribir código más legible
- Soporta múltiples bases de datos (MySQL, PostgreSQL, SQL Server)

**Middleware:**
- Funciones que se ejecutan **entre** la petición y la respuesta
- Pueden modificar `req` y `res`
- Se ejecutan en orden secuencial

```javascript
// Ejemplo de middleware
app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next(); // Pasa al siguiente middleware
});
```

**Hashing vs Encriptación:**
- **Hashing** (bcrypt): Irreversible, para contraseñas
- **Encriptación** (AES): Reversible, para datos sensibles

### 📊 Flujo de datos con Sequelize

```
JavaScript (Sequelize)
    ↓
ORM traduce a SQL
    ↓
Driver (tedious) envía query
    ↓
SQL Server ejecuta query
    ↓
Resultado regresa como objetos JS
    ↓
Tu código trabaja con objetos
```

---

## 3. ESTRUCTURA DEL PROYECTO

### 📁 Árbol de directorios completo

```
event-directory-api/
│
├── 📁 src/                          # Código fuente principal
│   │
│   ├── 📁 config/                   # ⚙️ Configuraciones
│   │   ├── db.config.js             # Conexión SQL Server (host, user, password)
│   │   ├── database.js              # Inicialización de Sequelize
│   │   └── server.config.js         # Variables de entorno (PORT, JWT_SECRET)
│   │
│   ├── 📁 models/                   # 🗄️ Modelos de datos (Tablas)
│   │   ├── index.js                 # Centraliza modelos y relaciones
│   │   ├── user.model.js            # Tabla: users
│   │   ├── category.model.js        # Tabla: categories
│   │   ├── event.model.js           # Tabla: events
│   │   ├── eventRegistration.model.js # Tabla: event_registrations
│   │   └── confirmationToken.model.js # Tabla: confirmation_tokens
│   │
│   ├── 📁 repositories/             # 💾 Acceso a datos (CRUD puro)
│   │   ├── event.repository.js      # Queries de eventos
│   │   └── user.repository.js       # Queries de usuarios
│   │
│   ├── 📁 services/                 # 🧠 Lógica de negocio
│   │   ├── event.service.js         # Validaciones y reglas de eventos
│   │   ├── auth.service.js          # Autenticación y registro
│   │   └── email.service.js         # Envío de correos
│   │
│   ├── 📁 controllers/              # 🌐 Manejo de HTTP
│   │   ├── event.controller.js      # Endpoints de eventos
│   │   └── auth.controller.js       # Endpoints de autenticación
│   │
│   ├── 📁 middlewares/              # 🛡️ Funciones intermedias
│   │   ├── auth.middleware.js       # Verificación de JWT
│   │   ├── errorHandler.js          # Manejo global de errores
│   │   └── notFound.js              # Respuesta 404
│   │
│   ├── 📁 routes/                   # 🛣️ Definición de rutas
│   │   ├── index.js                 # Router principal (agrupa todas)
│   │   ├── auth.routes.js           # Rutas: /auth/*
│   │   └── event.routes.js          # Rutas: /events/*
│   │
│   ├── 📁 utils/                    # 🔧 Utilidades reutilizables
│   │   └── jwt.util.js              # Generar/verificar tokens JWT
│   │
│   └── 📄 app.js                    # Configuración de Express
│
├── 📄 server.js                     # 🚀 Punto de entrada (inicia servidor)
├── 📄 .env                          # 🔐 Variables de entorno (NO SUBIR A GIT)
├── 📄 .env.example                  # 📋 Plantilla de .env
├── 📄 .gitignore                    # 🚫 Archivos ignorados por Git
├── 📄 package.json                  # 📦 Dependencias y scripts
├── 📄 package-lock.json             # 🔒 Versiones exactas de dependencias
├── 📄 README.md                     # 📖 Documentación del proyecto
├── 📄 MANUAL_PROYECTO.md            # 📚 Este manual
└── 📄 GUIA_JWT.md                   # 🔑 Guía de JWT
```

### 📌 Propósito de cada carpeta

| Carpeta | Responsabilidad | Ejemplo de archivo |
|---------|-----------------|-------------------|
| **config/** | Configuración de BD, variables de entorno | `db.config.js` → credenciales SQL Server |
| **models/** | Definición de tablas y relaciones | `user.model.js` → define campos de tabla users |
| **repositories/** | Operaciones CRUD directas a BD | `findAll()`, `create()`, `update()` |
| **services/** | Lógica de negocio, validaciones | Validar que usuario sea admin |
| **controllers/** | Recibir petición HTTP, enviar respuesta | `req.body` → `res.json()` |
| **middlewares/** | Funciones que procesan peticiones | Verificar token JWT antes de endpoint |
| **routes/** | Definir URLs y métodos HTTP | `GET /events`, `POST /auth/login` |
| **utils/** | Funciones reutilizables | Generar token JWT, enviar email |

### 🔄 Flujo de una petición HTTP (Ejemplo detallado)

```
1. Cliente → POST /api/v1/auth/login
             { email: "user@test.com", password: "123456" }

2. server.js → Inicia Express

3. app.js → Configura middlewares globales
            ├─ helmet() (seguridad)
            ├─ cors() (permite otros dominios)
            ├─ express.json() (parsea JSON)
            └─ morgan() (logger)

4. routes/index.js → Redirige a auth.routes.js

5. auth.routes.js → Encuentra ruta POST /login
                    → Ejecuta authController.login

6. middlewares/auth.middleware.js (si aplica)
   └─ verifyToken() → Verifica JWT si la ruta lo requiere

7. controllers/auth.controller.js
   └─ login(req, res, next)
       ├─ Valida entrada (req.body)
       ├─ Llama a authService.login()
       └─ Devuelve res.json()

8. services/auth.service.js
   └─ login(credentials)
       ├─ Validaciones de negocio
       ├─ Llama a userRepository.findByEmail()
       ├─ Compara contraseña con bcrypt
       └─ Genera token JWT

9. repositories/user.repository.js
   └─ findByEmail(email)
       └─ Ejecuta query: User.findOne({ where: { email } })

10. models/user.model.js
    └─ Define estructura de tabla 'users'

11. Base de datos SQL Server
    └─ Ejecuta SELECT * FROM users WHERE email = '...'

12. Respuesta viaja de vuelta:
    DB → Model → Repository → Service → Controller → Cliente

13. Cliente recibe:
    {
      "success": true,
      "data": {
        "user": { id: 1, name: "...", email: "..." },
        "accessToken": "eyJhbGci...",
        "refreshToken": "eyJhbGci...",
        "expiresIn": "24h"
      }
    }
```

### 🎯 Separación de responsabilidades

**❌ INCORRECTO (todo en un archivo):**
```javascript
// server.js (TODO JUNTO - MAL)
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const app = express();

app.post('/login', async (req, res) => {
    // Validación
    if (!req.body.email) return res.status(400).json({ error: 'Email requerido' });
    
    // Query directa
    const user = await db.User.findOne({ where: { email: req.body.email } });
    
    // Lógica de negocio
    const isValid = await bcrypt.compare(req.body.password, user.password);
    
    // Generación de token
    const token = jwt.sign({ id: user.id }, 'SECRET');
    
    res.json({ token });
});
```

**✅ CORRECTO (separado en capas):**
```javascript
// routes/auth.routes.js
router.post('/login', authController.login);

// controllers/auth.controller.js
const login = async (req, res, next) => {
    const result = await authService.login(req.body);
    res.json({ success: true, data: result });
};

// services/auth.service.js
const login = async (credentials) => {
    const user = await userRepository.findByEmail(credentials.email);
    const isValid = await bcrypt.compare(credentials.password, user.password);
    return generateTokenPair(user);
};

// repositories/user.repository.js
const findByEmail = (email) => {
    return User.findOne({ where: { email } });
};
```

---

## 4. CONFIGURACIÓN INICIAL

### 🔐 Archivo `.env` (Variables de entorno)

El archivo `.env` almacena configuración sensible que NO debe subirse a Git:

```env
# ==========================================
# CONFIGURACIÓN DE BASE DE DATOS SQL SERVER
# ==========================================
DB_HOST=DESKTOP-HECB7G0          # Nombre del servidor SQL
DB_USER=sa                        # Usuario de SQL Server
DB_PASSWORD=Pass123               # Contraseña (CAMBIAR en producción)
DB_NAME=events_db                 # Nombre de la base de datos
DB_PORT=1433                      # Puerto (por defecto 1433)

# ==========================================
# CONFIGURACIÓN DEL SERVIDOR
# ==========================================
PORT=3000                         # Puerto donde corre Express
NODE_ENV=development              # Entorno: development | production | test

# ==========================================
# CONFIGURACIÓN DE JWT (JSON Web Token)
# ==========================================
# ⚠️ GENERAR CLAVE SEGURA CON:
# node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
JWT_SECRET=92af0cd65715ac0c8a77eab101863e2f304c1113ddeb426d3d77e634b0cce56b6a43e9155c88ca455340b23a35bd81b4db64a4f023460d2a005110d4ebf72ced
JWT_EXPIRES_IN=24h                # Token de acceso: 15m, 1h, 24h, 7d
JWT_REFRESH_EXPIRES_IN=7d         # Refresh token: 7d, 30d, 90d
JWT_ISSUER=event-directory-api    # Quién emite el token
JWT_AUDIENCE=event-directory-app  # Para quién es el token

# ==========================================
# CONFIGURACIÓN DE EMAIL (Nodemailer)
# ==========================================
EMAIL_SERVICE=gmail
EMAIL_USER=tu.correo@gmail.com
EMAIL_PASS=tu_password_app        # Password de aplicación de Gmail
EMAIL_FROM=noreply@eventdirectory.com

# ==========================================
# CONFIGURACIÓN DE CORS
# ==========================================
CORS_ORIGIN=*                     # * = todos (desarrollo) | http://miapp.com (producción)
```

### 📝 ¿Cómo usar variables de entorno?

**1. Cargar dotenv al inicio:**
```javascript
// server.js (PRIMERO DE TODO)
require('dotenv').config();

console.log(process.env.PORT); // 3000
console.log(process.env.DB_NAME); // events_db
```

**2. Acceder a variables:**
```javascript
// src/config/server.config.js
module.exports = {
    port: process.env.PORT || 3000,
    nodeEnv: process.env.NODE_ENV || 'development',
    jwt: {
        secret: process.env.JWT_SECRET,
        expiresIn: process.env.JWT_EXPIRES_IN || '24h',
        issuer: process.env.JWT_ISSUER,
        audience: process.env.JWT_AUDIENCE
    }
};
```

### 📋 Scripts en `package.json`

```json
{
  "name": "event-directory-api",
  "version": "1.0.0",
  "description": "API REST para gestión de eventos",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js",
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "keywords": ["events", "api", "rest", "jwt", "sequelize"],
  "author": "Tu Nombre",
  "license": "ISC"
}
```

### ▶️ Comandos de ejecución

```bash
# Desarrollo (auto-reload con nodemon)
npm run dev

# Producción
npm start

# Ver logs en tiempo real
npm run dev | grep "Error"
```

### 🔒 Seguridad: ¿Qué NO subir a Git?

**Archivo `.gitignore`:**
```gitignore
# Node modules
node_modules/

# Variables de entorno (¡IMPORTANTE!)
.env
.env.local
.env.*.local

# Logs
logs/
*.log
npm-debug.log*

# Sistema operativo
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/
*.swp
```

### 🎓 Diferencia entre `.env` y `.env.example`

| Archivo | Propósito | ¿Subir a Git? |
|---------|-----------|---------------|
| `.env` | Valores REALES (contraseñas, secrets) | ❌ NO |
| `.env.example` | Plantilla SIN valores sensibles | ✅ SÍ |

**Ejemplo `.env.example`:**
```env
DB_HOST=localhost
DB_USER=tu_usuario
DB_PASSWORD=tu_password
DB_NAME=events_db
JWT_SECRET=GENERA_CON_CRYPTO_RANDOMBYTES
```

### 🚀 Pasos para iniciar el proyecto

```bash
# 1. Clonar repositorio
git clone https://github.com/tu-usuario/event-directory-api.git
cd event-directory-api

# 2. Instalar dependencias
npm install

# 3. Copiar plantilla de variables de entorno
copy .env.example .env          # Windows
# o
cp .env.example .env            # Linux/Mac

# 4. Editar .env con tus valores reales
notepad .env                    # Windows
# o
nano .env                       # Linux

# 5. Generar JWT_SECRET seguro
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"

# 6. Crear base de datos en SQL Server
# Ejecutar en SQL Server Management Studio:
# CREATE DATABASE events_db;

# 7. Iniciar servidor
npm run dev

# 8. Verificar que está corriendo
# Abrir navegador: http://localhost:3000/api/v1/health
```

---

## 5. ARQUITECTURA CSR EXPLICADA

### 🏗️ ¿Qué es el patrón Controller-Service-Repository?

Es una arquitectura en **3 capas** que separa responsabilidades:

```
                    Cliente (Postman, React, Angular, etc.)
                              ↓ HTTP Request
                    ┌─────────────────────┐
                    │    🌐 CONTROLLER     │
                    │  Capa HTTP/REST      │
                    │  · req.body          │
                    │  · req.params        │
                    │  · res.json()        │
                    │  · res.status()      │
                    └──────────┬───────────┘
                               ↓
                    ┌─────────────────────┐
                    │    🧠 SERVICE        │
                    │  Lógica de negocio   │
                    │  · Validaciones      │
                    │  · Permisos          │
                    │  · Reglas de negocio │
                    │  · Cálculos          │
                    └──────────┬───────────┘
                               ↓
                    ┌─────────────────────┐
                    │   💾 REPOSITORY      │
                    │  Acceso a datos      │
                    │  · findAll()         │
                    │  · create()          │
                    │  · update()          │
                    │  · delete()          │
                    └──────────┬───────────┘
                               ↓
                    ┌─────────────────────┐
                    │    🗄️ MODEL          │
                    │  Definición tabla    │
                    │  · Campos            │
                    │  · Tipos de datos    │
                    │  · Relaciones        │
                    └──────────┬───────────┘
                               ↓
                         SQL Server
```

### 📌 Responsabilidades de cada capa

| Capa | ¿Qué hace? | ¿Qué NO hace? | Ejemplo |
|------|------------|---------------|---------|
| **Controller** | Manejar HTTP: recibe `req`, devuelve `res` | ❌ NO hace queries a BD | `res.status(200).json(data)` |
| **Service** | Lógica de negocio, validaciones, permisos | ❌ NO conoce `req`/`res` | `if (user.role !== 'admin') throw Error()` |
| **Repository** | CRUD puro: `findAll`, `create`, `update` | ❌ NO valida reglas de negocio | `Event.findAll({ where: { ... } })` |
| **Model** | Define estructura de tabla | ❌ NO ejecuta queries | `title: DataTypes.STRING` |

### 💡 Ejemplo completo: Crear un evento

#### 1️⃣ **Route** (define la URL)
```javascript
// src/routes/event.routes.js
const router = require('express').Router();
const eventController = require('../controllers/event.controller');
const { verifyToken } = require('../middlewares/auth.middleware');

router.post('/', verifyToken, eventController.createEvent);
//             ↑ Middleware    ↑ Controlador
```

#### 2️⃣ **Controller** (maneja HTTP)
```javascript
// src/controllers/event.controller.js
const eventService = require('../services/event.service');

const createEvent = async (req, res, next) => {
    try {
        // 1. Obtener datos de la petición
        const eventData = req.body;
        const userId = req.user.id; // viene del middleware verifyToken
        
        // 2. Delegar al servicio
        const newEvent = await eventService.createEvent(eventData, userId);
        
        // 3. Responder con éxito
        res.status(201).json({
            success: true,
            message: 'Evento creado exitosamente',
            data: { event: newEvent }
        });
    } catch (error) {
        // 4. Manejar errores
        next(error);
    }
};

module.exports = { createEvent };
```

**Responsabilidades del Controller:**
- ✅ Extraer datos de `req.body`, `req.params`, `req.user`
- ✅ Llamar al Service
- ✅ Enviar respuesta HTTP con código de estado apropiado
- ✅ Manejar errores

**NO hace:**
- ❌ Validaciones de negocio (eso es del Service)
- ❌ Queries a la BD (eso es del Repository)

#### 3️⃣ **Service** (lógica de negocio)
```javascript
// src/services/event.service.js
const eventRepository = require('../repositories/event.repository');

const createEvent = async (eventData, userId) => {
    // 1. Validar datos de entrada
    if (!eventData.title || eventData.title.length < 3) {
        throw new Error('El título debe tener al menos 3 caracteres');
    }
    
    if (!eventData.description) {
        throw new Error('La descripción es requerida');
    }
    
    // 2. Validar maxCapacity
    if (eventData.maxCapacity && eventData.maxCapacity < 1) {
        throw new Error('La capacidad máxima debe ser mayor a 0');
    }
    
    // 3. Establecer valores por defecto
    const eventToCreate = {
        ...eventData,
        createdBy: userId,
        availableSpots: eventData.maxCapacity || null,
        status: 'draft', // Por defecto está en borrador
        slug: eventData.title.toLowerCase().replace(/\s+/g, '-')
    };
    
    // 4. Delegar al repository para guardar en BD
    const newEvent = await eventRepository.create(eventToCreate);
    
    // 5. Retornar evento creado
    return newEvent;
};

module.exports = { createEvent };
```

**Responsabilidades del Service:**
- ✅ Validar reglas de negocio
- ✅ Verificar permisos
- ✅ Calcular valores derivados (slug, availableSpots)
- ✅ Coordinar múltiples repositories si es necesario
- ✅ Lanzar errores descriptivos

**NO hace:**
- ❌ Conocer de `req` o `res` (no sabe que viene de HTTP)
- ❌ Queries directas a BD (usa el Repository)

#### 4️⃣ **Repository** (acceso a datos)
```javascript
// src/repositories/event.repository.js
const db = require('../models');

const create = async (eventData) => {
    // Solo ejecuta la query de Sequelize
    return await db.Event.create(eventData);
};

const findAll = async (filters = {}) => {
    return await db.Event.findAll({
        where: filters,
        include: [
            { model: db.Category, as: 'category' },
            { model: db.User, as: 'creator', attributes: ['id', 'name', 'email'] }
        ],
        order: [['createdAt', 'DESC']]
    });
};

const findById = async (id) => {
    return await db.Event.findByPk(id, {
        include: [
            { model: db.Category, as: 'category' },
            { model: db.User, as: 'creator', attributes: ['id', 'name', 'email'] },
            { model: db.EventRegistration, as: 'registrations' }
        ]
    });
};

const update = async (id, updateData) => {
    const event = await db.Event.findByPk(id);
    if (!event) return null;
    return await event.update(updateData);
};

const deleteEvent = async (id) => {
    const event = await db.Event.findByPk(id);
    if (!event) return null;
    await event.destroy();
    return event;
};

module.exports = {
    create,
    findAll,
    findById,
    update,
    deleteEvent
};
```

**Responsabilidades del Repository:**
- ✅ Ejecutar queries con Sequelize
- ✅ Incluir relaciones (`include`)
- ✅ Ordenar y filtrar resultados
- ✅ Retornar datos crudos de BD

**NO hace:**
- ❌ Validar reglas de negocio
- ❌ Verificar permisos
- ❌ Lanzar errores de validación (solo errores de BD)

#### 5️⃣ **Model** (definición de tabla)
```javascript
// src/models/event.model.js
module.exports = (sequelize, DataTypes) => {
    const Event = sequelize.define('Event', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        title: {
            type: DataTypes.STRING(200),
            allowNull: false
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        slug: {
            type: DataTypes.STRING(250),
            unique: true
        },
        maxCapacity: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        availableSpots: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        status: {
            type: DataTypes.ENUM('draft', 'published', 'cancelled', 'completed'),
            defaultValue: 'draft'
        }
    }, {
        tableName: 'events',
        timestamps: true // createdAt, updatedAt
    });
    
    return Event;
};
```

### ✅ Ventajas del patrón CSR

| Beneficio | Explicación | Ejemplo |
|-----------|-------------|---------|
| **Reutilización** | Un repository puede usarse en múltiples services | `userRepository.findById()` usado en auth y perfil |
| **Testeable** | Cada capa se prueba independientemente | Mock del repository para testear service |
| **Mantenible** | Cambios en BD solo afectan repositories | Cambiar Sequelize por Prisma: solo editar repositories |
| **Escalable** | Fácil agregar funcionalidades | Nuevo endpoint solo necesita nuevo controller |
| **Claridad** | Cada archivo tiene un propósito claro | Leer `event.service.js` y entender lógica de eventos |

### ❌ Antipatrones comunes (qué evitar)

**1. Controller con lógica de negocio:**
```javascript
// ❌ MAL
const createEvent = async (req, res) => {
    if (req.body.maxCapacity < 1) { // ← validación en controller
        return res.status(400).json({ error: 'Capacidad inválida' });
    }
    const event = await db.Event.create(req.body); // ← query directa
    res.json(event);
};

// ✅ BIEN
const createEvent = async (req, res) => {
    const event = await eventService.createEvent(req.body, req.user.id);
    res.status(201).json({ success: true, data: { event } });
};
```

**2. Service con queries directas:**
```javascript
// ❌ MAL
const createEvent = async (eventData) => {
    // Service NO debe hacer queries directas
    const event = await db.Event.create(eventData);
    return event;
};

// ✅ BIEN
const createEvent = async (eventData) => {
    // Service usa el repository
    const event = await eventRepository.create(eventData);
    return event;
};
```

**3. Repository con validaciones de negocio:**
```javascript
// ❌ MAL
const create = async (eventData) => {
    if (eventData.maxCapacity < 1) { // ← validación en repository
        throw new Error('Capacidad inválida');
    }
    return await db.Event.create(eventData);
};

// ✅ BIEN
const create = async (eventData) => {
    // Repository solo ejecuta query
    return await db.Event.create(eventData);
};
```

### 🎓 Regla mnemotécnica

```
Controller → "HTTP Police"      → Solo maneja req/res
Service    → "Business Brain"    → Piensa y valida
Repository → "Database Worker"   → Solo ejecuta queries
Model      → "Table Blueprint"   → Solo define estructura
```

---

## 5. MODELOS Y RELACIONES

### 📊 Diagrama de base de datos

```
┌─────────────┐
│    User     │
│─────────────│
│ id          │──┐
│ name        │  │
│ email       │  │ 1:N (creador)
│ password    │  │
│ role        │  │
└─────────────┘  │
                 │
                 ▼
              ┌─────────────┐      ┌──────────────┐
              │   Event     │──────│   Category   │
              │─────────────│ N:1  │──────────────│
              │ id          │      │ id           │
              │ title       │      │ name         │
              │ description │      │ slug         │
              │ categoryId  │◄─────│ color        │
              │ createdBy   │      └──────────────┘
              │ maxCapacity │
              │ startDate   │
              └──────┬──────┘
                     │ 1:N
                     ▼
        ┌──────────────────────┐
        │ EventRegistration    │
        │──────────────────────│
        │ id                   │
        │ eventId              │
        │ userId (opcional)    │
        │ attendeeName         │
        │ attendeeEmail        │
        │ isConfirmed          │
        └──────────────────────┘
```

### 📝 Modelos implementados

| Modelo | Descripción | Campos principales |
|--------|-------------|-------------------|
| **User** | Usuarios del sistema | name, email, password, role, isActive |
| **Category** | Categorías de eventos | name, slug, description, color, icon |
| **Event** | Eventos publicados | title, description, categoryId, createdBy, maxCapacity |
| **EventRegistration** | Registros de asistencia | eventId, userId, attendeeName, isConfirmed |
| **ConfirmationToken** | Tokens de confirmación | token, type, expiresAt, userId |

### 🔗 Relaciones entre modelos

```javascript
// Category → Event (1:N)
Category.hasMany(Event, { foreignKey: 'categoryId', as: 'events' });
Event.belongsTo(Category, { foreignKey: 'categoryId', as: 'category' });

// User → Event (1:N - como creador)
User.hasMany(Event, { foreignKey: 'createdBy', as: 'createdEvents' });
Event.belongsTo(User, { foreignKey: 'createdBy', as: 'creator' });

// Event → EventRegistration (1:N)
Event.hasMany(EventRegistration, { foreignKey: 'eventId', as: 'registrations' });
EventRegistration.belongsTo(Event, { foreignKey: 'eventId', as: 'event' });

// User → EventRegistration (1:N - opcional)
User.hasMany(EventRegistration, { foreignKey: 'userId', as: 'eventRegistrations' });
EventRegistration.belongsTo(User, { foreignKey: 'userId', as: 'user' });
```

---

## 6. AUTENTICACIÓN JWT

### 🔐 ¿Qué es JWT?

**JSON Web Token** - Token firmado digitalmente que contiene información del usuario.

```
Header.Payload.Signature
```

### 🔑 Generar JWT_SECRET seguro

```bash
# Método 1: Node.js
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"

# Método 2: PowerShell
-join ((48..57) + (65..90) + (97..122) | Get-Random -Count 64 | % {[char]$_})
```

### 📋 Flujo de autenticación

```
1. Usuario → POST /api/v1/auth/login { email, password }
2. Servidor verifica credenciales
3. Servidor genera JWT firmado
4. Servidor responde: { accessToken, refreshToken, user }
5. Cliente guarda token (localStorage/cookie)
6. Cliente envía token en cada petición:
   Authorization: Bearer <token>
7. Servidor verifica token en middleware
8. Si es válido → req.user tiene datos del usuario
```

### 🛡️ Configuración de tiempos

```env
JWT_EXPIRES_IN=24h          # Access token (recomendado: 15m - 24h)
JWT_REFRESH_EXPIRES_IN=7d   # Refresh token (recomendado: 7d - 30d)
```

**Valores válidos:** `15m`, `1h`, `24h`, `7d`, `30d`, `90d`

---

## 7. MIDDLEWARES

### 🔧 Middlewares implementados

| Middleware | Ubicación | Propósito |
|------------|-----------|-----------|
| `verifyToken` | auth.middleware.js | Autenticación obligatoria con JWT |
| `checkRole(...)` | auth.middleware.js | Verificar roles específicos |
| `requireEmailVerification` | auth.middleware.js | Requiere email verificado |
| `optionalAuth` | auth.middleware.js | Autenticación opcional |
| `errorHandler` | errorHandler.js | Manejo global de errores |
| `notFound` | notFound.js | Manejo de rutas 404 |

### 💡 Ejemplos de uso

```javascript
// 1. Ruta pública (sin auth)
router.get('/events', eventController.getAllEvents);

// 2. Ruta protegida (requiere auth)
router.post('/events', verifyToken, eventController.createEvent);

// 3. Solo admin y organizadores
router.delete('/events/:id', 
  verifyToken, 
  checkRole('admin', 'organizer'), 
  eventController.deleteEvent
);

// 4. Requiere email verificado
router.post('/events/:id/register', 
  verifyToken, 
  requireEmailVerification, 
  registrationController.register
);

// 5. Auth opcional (cambia comportamiento si está autenticado)
router.get('/events', optionalAuth, eventController.getAllEvents);
```

---

## 8. ENDPOINTS DISPONIBLES

### 🌐 Base URL

```
http://localhost:3000/api/v1
```

### 📍 Autenticación (`/auth`)

| Método | Endpoint | Auth | Descripción |
|--------|----------|------|-------------|
| POST | `/auth/register` | ❌ No | Registrar nuevo usuario |
| POST | `/auth/login` | ❌ No | Iniciar sesión (devuelve JWT) |
| GET | `/auth/profile` | ✅ Sí | Obtener perfil del usuario autenticado |
| PUT | `/auth/profile` | ✅ Sí | Actualizar perfil |
| POST | `/auth/forgot-password` | ❌ No | Solicitar recuperación de contraseña |
| POST | `/auth/reset-password` | ❌ No | Restablecer contraseña |

### 📍 Eventos (`/events`)

| Método | Endpoint | Auth | Descripción |
|--------|----------|------|-------------|
| GET | `/events` | ❌ No | Listar eventos con filtros y paginación |
| GET | `/events/:id` | ❌ No | Ver detalles de un evento |
| POST | `/events` | ✅ Sí | Crear nuevo evento |
| PUT | `/events/:id` | ✅ Sí | Actualizar evento (solo creador/admin) |
| DELETE | `/events/:id` | ✅ Sí | Eliminar evento (solo creador/admin) |

### 🔍 Filtros en GET /events

```
?page=1                  # Página (default: 1)
?limit=10                # Eventos por página (default: 10)
?categoryId=1            # Filtrar por categoría
?search=tech             # Buscar en título/descripción
?status=published        # Filtrar por estado
?startDate=2025-01-01    # Eventos desde esta fecha
?endDate=2025-12-31      # Eventos hasta esta fecha
```

### 📝 Ejemplos de peticiones

#### Registro de usuario

```bash
curl -X POST http://localhost:3000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Juan Pérez",
    "email": "juan@example.com",
    "password": "Password123",
    "phone": "6641234567"
  }'
```

#### Login

```bash
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "juan@example.com",
    "password": "Password123"
  }'
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Login exitoso",
  "data": {
    "user": { ... },
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expiresIn": "24h"
  }
}
```

#### Acceder a ruta protegida

```bash
curl -X GET http://localhost:3000/api/v1/auth/profile \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

#### Crear evento

```bash
curl -X POST http://localhost:3000/api/v1/events \
  -H "Authorization: Bearer <tu_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Conferencia Tech 2025",
    "description": "Evento de tecnología",
    "categoryId": 1,
    "maxCapacity": 100,
    "startDate": "2025-06-15T10:00:00",
    "endDate": "2025-06-15T18:00:00",
    "location": "Centro de Convenciones"
  }'
```

---

## 9. COMANDOS ÚTILES

### 🚀 Desarrollo

```bash
# Instalar dependencias
npm install

# Ejecutar en modo desarrollo (auto-reload)
npm run dev

# Ejecutar en producción
npm start

# Generar JWT_SECRET
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

### 🗄️ Base de datos

```sql
-- Crear base de datos
CREATE DATABASE events_db;

-- Ver tablas creadas
USE events_db;
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE';

-- Ver registros de usuarios
SELECT id, name, email, role, isActive FROM users;

-- Ver eventos
SELECT id, title, status, maxCapacity, availableSpots FROM events;
```

### 🧪 Testing con cURL

```bash
# Health check
curl http://localhost:3000/api/v1/health

# Listar eventos
curl http://localhost:3000/api/v1/events

# Ver evento específico
curl http://localhost:3000/api/v1/events/1

# Login
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"Test123"}'
```

### 🔍 Debugging

```bash
# Ver logs en tiempo real con nodemon
npm run dev

# Ver variables de entorno cargadas
node -e "require('dotenv').config(); console.log(process.env.JWT_SECRET)"

# Verificar conexión a SQL Server
node -e "const db = require('./src/models'); db.sequelize.authenticate().then(() => console.log('✅ Conectado')).catch(e => console.error('❌', e))"
```

---

## 📚 RECURSOS ADICIONALES

### 📖 Documentación oficial

- [Express.js](https://expressjs.com/)
- [Sequelize ORM](https://sequelize.org/)
- [JWT](https://jwt.io/)
- [Bcrypt](https://www.npmjs.com/package/bcrypt)

### 🎓 Mejores prácticas

1. ✅ Nunca subir `.env` a GitHub (agregar a `.gitignore`)
2. ✅ Usar diferentes `JWT_SECRET` en desarrollo y producción
3. ✅ Hash de contraseñas con bcrypt (nunca texto plano)
4. ✅ Validar entrada del usuario en controllers
5. ✅ Usar migrations en producción (no `sync()`)
6. ✅ Implementar rate limiting en producción
7. ✅ Agregar logs estructurados (Winston/Morgan)
8. ✅ Implementar validación con Joi o express-validator

### 🔐 Seguridad

```bash
# Instalar helmet (ya instalado)
npm install helmet

# Instalar rate limiting
npm install express-rate-limit

# Instalar validación
npm install joi
# o
npm install express-validator
```

---

## 📞 CONTACTO Y SOPORTE

- **Proyecto:** Event Directory API
- **Versión:** 1.0.0
- **Fecha:** Noviembre 2025

---

**✨ ¡Listo para desarrollar!**