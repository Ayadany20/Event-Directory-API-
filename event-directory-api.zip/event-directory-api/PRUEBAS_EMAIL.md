# 🧪 PRUEBAS DEL SERVICIO DE EMAIL

## ⚠️ IMPORTANTE: Primero necesitas un token de admin

### 1. Registrar un usuario admin (si no tienes uno)

```bash
curl -X POST http://localhost:3000/api/v1/auth/register ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Admin User\",\"email\":\"admin@test.com\",\"password\":\"Admin123\",\"role\":\"admin\"}"
```

### 2. Hacer login y obtener token

```bash
curl -X POST http://localhost:3000/api/v1/auth/login ^
  -H "Content-Type: application/json" ^
  -d "{\"email\":\"admin@test.com\",\"password\":\"Admin123\"}"
```

**Guarda el `accessToken` que recibes en la respuesta.**

---

## 🧪 PRUEBAS DE LOS ENDPOINTS

### Prueba 1: Verificar conexión de email ✅

```bash
curl -X GET http://localhost:3000/api/v1/email/verify ^
  -H "Authorization: Bearer TU_TOKEN_AQUI"
```

**Resultado esperado:**
```json
{
  "success": true,
  "message": "Conexión con el servidor de email verificada exitosamente",
  "data": {
    "service": "gmail",
    "user": "master.androis1029@gmail.com",
    "from": "master.androis1029@gmail.com"
  }
}
```

---

### Prueba 2: Enviar email de prueba 📧

**Reemplaza `tu.email@gmail.com` con tu email real para recibir el mensaje**

```bash
curl -X POST http://localhost:3000/api/v1/email/test ^
  -H "Authorization: Bearer TU_TOKEN_AQUI" ^
  -H "Content-Type: application/json" ^
  -d "{\"to\":\"tu.email@gmail.com\"}"
```

**Resultado esperado:**
```json
{
  "success": true,
  "message": "Email de prueba enviado exitosamente",
  "data": {
    "success": true,
    "messageId": "<...@gmail.com>",
    "to": "tu.email@gmail.com",
    "subject": "📧 Email de Prueba - Event Directory API"
  }
}
```

**Revisa tu bandeja de entrada (o spam) para ver el email.**

---

### Prueba 3: Enviar email genérico personalizado 📝

```bash
curl -X POST http://localhost:3000/api/v1/email/send ^
  -H "Authorization: Bearer TU_TOKEN_AQUI" ^
  -H "Content-Type: application/json" ^
  -d "{\"to\":\"tu.email@gmail.com\",\"subject\":\"Hola desde mi API\",\"html\":\"<h1>¡Funciona!</h1><p>Este email fue enviado desde mi API de Express.js</p>\"}"
```

---

### Prueba 4: Enviar email de bienvenida 🎉

```bash
curl -X POST http://localhost:3000/api/v1/email/welcome ^
  -H "Authorization: Bearer TU_TOKEN_AQUI" ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Juan Pérez\",\"email\":\"tu.email@gmail.com\",\"role\":\"user\"}"
```

**Este email tiene diseño profesional con CSS y formato HTML.**

---

### Prueba 5: Enviar confirmación de evento 🎫

```bash
curl -X POST http://localhost:3000/api/v1/email/event-confirmation ^
  -H "Authorization: Bearer TU_TOKEN_AQUI" ^
  -H "Content-Type: application/json" ^
  -d "{\"userName\":\"María García\",\"userEmail\":\"tu.email@gmail.com\",\"eventTitle\":\"Conferencia Tech 2025\",\"eventDescription\":\"Evento de tecnología e innovación\",\"eventStartDate\":\"2025-06-15T10:00:00\",\"eventLocation\":\"Centro de Convenciones\"}"
```

---

## 📊 VERIFICAR LOGS DEL SERVIDOR

Después de cada prueba, revisa la consola del servidor (donde ejecutaste `npm run dev`).

Deberías ver mensajes como:

```
📧 Email enviado a tu.email@gmail.com: <abc123@gmail.com>
```

---

## 🐛 SOLUCIÓN DE PROBLEMAS

### Error: "Invalid login: 535-5.7.8 Username and Password not accepted"

**Causa:** Contraseña incorrecta o no es contraseña de aplicación

**Solución:**
1. Ve a https://myaccount.google.com/security
2. Activa verificación en 2 pasos
3. Ve a "Contraseñas de aplicaciones"
4. Genera una nueva para "Correo"
5. Copia la contraseña de 16 caracteres (sin espacios)
6. Actualiza `EMAIL_PASS` en tu `.env`
7. Reinicia el servidor: `npm run dev`

---

### Error: "Connection timeout"

**Causa:** Problemas de red o firewall

**Solución:**
1. Verifica tu conexión a internet
2. Intenta cambiar en `.env`:
   ```env
   EMAIL_PORT=465
   EMAIL_SECURE=true
   ```
3. Reinicia el servidor

---

### Error: 401 Unauthorized

**Causa:** Token inválido o expirado

**Solución:**
1. Haz login nuevamente para obtener un token nuevo
2. Copia el `accessToken` completo
3. Úsalo en el header: `Authorization: Bearer TOKEN_AQUI`

---

### Error: 403 Forbidden

**Causa:** Tu usuario no tiene rol de admin

**Solución:**
1. Verifica que tu usuario tenga `"role": "admin"`
2. O registra un nuevo usuario con rol admin
3. O actualiza el rol en la base de datos directamente

---

### Email no llega

**Soluciones:**
1. ✅ Revisa la carpeta de SPAM
2. ✅ Verifica que el email destino sea válido
3. ✅ Revisa los logs del servidor (debe aparecer "📧 Email enviado...")
4. ✅ Verifica que `EMAIL_USER` y `EMAIL_FROM` sean el mismo email
5. ✅ Intenta enviar a otro email

---

## ✅ CHECKLIST DE CONFIGURACIÓN

Antes de hacer las pruebas, verifica:

- [ ] `EMAIL_USER` está configurado en `.env`
- [ ] `EMAIL_PASS` es una contraseña de aplicación (16 caracteres)
- [ ] `EMAIL_FROM` está configurado
- [ ] `EMAIL_SERVICE=gmail`
- [ ] Verificación en 2 pasos activada en Google
- [ ] Servidor corriendo (`npm run dev`)
- [ ] Token de admin obtenido
- [ ] nodemailer instalado (`npm install nodemailer`)

---

## 📸 EJEMPLO DE EMAIL DE BIENVENIDA

Cuando envíes el email de bienvenida, verás algo así:

```
┌────────────────────────────────┐
│      🎉 ¡Bienvenido!           │
│  (Fondo degradado morado)      │
└────────────────────────────────┘

Hola Juan Pérez,

¡Gracias por registrarte en Event Directory!

Tu cuenta ha sido creada exitosamente. Ahora puedes:
  ✅ Explorar eventos increíbles
  ✅ Crear tus propios eventos
  ✅ Registrarte en eventos
  ✅ Conectar con otros usuarios

Email: juan@example.com
Rol: Usuario

[Ver Eventos] (botón)

─────────────────────────────────
Event Directory API © 2025
Si no solicitaste esta cuenta, 
por favor ignora este correo.
```

---

## 🎯 PRÓXIMOS PASOS

Una vez que funcionen las pruebas básicas:

1. ✅ Integrar envío automático al registrar usuario
2. ✅ Integrar confirmación al registrarse a evento
3. ✅ Implementar recuperación de contraseña con email
4. ✅ Agregar plantillas personalizadas
5. ✅ Implementar rate limiting para prevenir spam

---

**✨ ¡Listo para enviar emails profesionales!**
