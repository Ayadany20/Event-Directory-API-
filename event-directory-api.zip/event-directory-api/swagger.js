const swaggerJsdoc = require('swagger-jsdoc');

const options = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: 'Event Directory API',
            version: '1.0.0',
            description: 'API RESTful para gestión de eventos con autenticación JWT',
            contact: {
                name: 'Ayadany Mesino',
                email: 'mesinoayadany14@gmail.com'
            }
        },
        servers: [
            {
                url: 'http://localhost:3000',
                description: 'Servidor de desarrollo'
            },
            {
                url: 'https://api.example.com',
                description: 'Servidor de producción'
            }
        ],
        components: {
            securitySchemes: {
                bearerAuth: {
                    type: 'http',
                    scheme: 'bearer',
                    bearerFormat: 'JWT',
                    description: 'JWT Authorization header usando Bearer schema'
                }
            },
            schemas: {
                User: {
                    type: 'object',
                    properties: {
                        id: { type: 'integer', example: 1 },
                        name: { type: 'string', example: 'Ayadany Mesino' },
                        email: { type: 'string', example: 'mesinoayadany14@gmail.com' },
                        password: { type: 'string', example: 'hashed_password' },
                        phone: { type: 'string', example: '+1234567890' },
                        role: { type: 'string', enum: ['user', 'admin'], example: 'user' },
                        isActive: { type: 'boolean', example: true },
                        isEmailVerified: { type: 'boolean', example: false },
                        createdAt: { type: 'string', format: 'date-time' },
                        updatedAt: { type: 'string', format: 'date-time' }
                    }
                },
                Event: {
                    type: 'object',
                    properties: {
                        id: { type: 'integer', example: 1 },
                        title: { type: 'string', example: 'Festival de Jazz 2025' },
                        description: { type: 'string', example: 'Un festival con los mejores artistas de jazz' },
                        location: { type: 'string', example: 'Auditorio Nacional' },
                        address: { type: 'string', example: 'Av. Reforma 1234' },
                        city: { type: 'string', example: 'Ciudad de México' },
                        state: { type: 'string', example: 'CDMX' },
                        startDate: { type: 'string', format: 'date-time', example: '2025-06-20T18:00:00Z' },
                        endDate: { type: 'string', format: 'date-time', example: '2025-06-22T23:00:00Z' },
                        maxCapacity: { type: 'integer', example: 500 },
                        availableSpots: { type: 'integer', example: 500 },
                        slug: { type: 'string', example: 'festival-jazz-2025' },
                        categoryId: { type: 'integer', example: 1 },
                        createdBy: { type: 'integer', example: 1 },
                        status: { type: 'string', enum: ['draft', 'published', 'cancelled'], example: 'published' },
                        price: { type: 'number', example: 1500 },
                        isFree: { type: 'boolean', example: false },
                        createdAt: { type: 'string', format: 'date-time' },
                        updatedAt: { type: 'string', format: 'date-time' }
                    }
                },
                Category: {
                    type: 'object',
                    properties: {
                        id: { type: 'integer', example: 1 },
                        name: { type: 'string', example: 'Música' },
                        slug: { type: 'string', example: 'musica' },
                        color: { type: 'string', example: '#FF5733' },
                        createdAt: { type: 'string', format: 'date-time' },
                        updatedAt: { type: 'string', format: 'date-time' }
                    }
                },
                LoginRequest: {
                    type: 'object',
                    required: ['email', 'password'],
                    properties: {
                        email: { type: 'string', example: 'mesinoayadany14@gmail.com' },
                        password: { type: 'string', example: '12345678' }
                    }
                },
                RegisterRequest: {
                    type: 'object',
                    required: ['name', 'email', 'password'],
                    properties: {
                        name: { type: 'string', example: 'Ayadany Mesino' },
                        email: { type: 'string', example: 'mesinoayadany14@gmail.com' },
                        password: { type: 'string', example: '12345678' },
                        phone: { type: 'string', example: '+1234567890' }
                    }
                },
                CreateEventRequest: {
                    type: 'object',
                    required: ['title', 'description', 'location', 'startDate', 'endDate', 'categoryId'],
                    properties: {
                        title: { type: 'string', example: 'Festival de Jazz 2025' },
                        description: { type: 'string', example: 'Un festival con los mejores artistas de jazz' },
                        location: { type: 'string', example: 'Auditorio Nacional' },
                        address: { type: 'string', example: 'Av. Reforma 1234' },
                        city: { type: 'string', example: 'Ciudad de México' },
                        state: { type: 'string', example: 'CDMX' },
                        startDate: { type: 'string', format: 'date-time', example: '2025-06-20T18:00:00Z' },
                        endDate: { type: 'string', format: 'date-time', example: '2025-06-22T23:00:00Z' },
                        maxCapacity: { type: 'integer', example: 500 },
                        categoryId: { type: 'integer', example: 1 },
                        price: { type: 'number', example: 1500 },
                        isFree: { type: 'boolean', example: false }
                    }
                },
                ApiResponse: {
                    type: 'object',
                    properties: {
                        success: { type: 'boolean', example: true },
                        message: { type: 'string', example: 'Operación exitosa' },
                        data: { type: 'object' }
                    }
                }
            }
        }
    },
    apis: [
        './src/routes/auth.routes.js',
        './src/routes/event.routes.js'
    ]
};

const swaggerSpec = swaggerJsdoc(options);

module.exports = swaggerSpec;
