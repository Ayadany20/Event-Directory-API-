// server.js
const dotenv = require('dotenv');
const app = require('./src/app');
const serverConfig = require('./src/config/server.config');
const { initializeDatabase, closeDatabase } = require('./src/config/database');

// Cargar variables de entorno
dotenv.config();

// Variable para el servidor
let server;

// ==================== INICIAR APLICACIÓN ====================
const startServer = async () => {
    try {
        // 1. Inicializar base de datos
        await initializeDatabase(app);

        // 2. Iniciar servidor HTTP
        server = app.listen(serverConfig.port, () => {
            console.log(`\n${'='.repeat(60)}`);
            console.log(`🚀 ${serverConfig.app.name} v${serverConfig.app.version}`);
            console.log(`${'='.repeat(60)}`);
            console.log(`📡 Servidor: http://localhost:${serverConfig.port}`);
            console.log(`🌍 Entorno: ${serverConfig.nodeEnv}`);
            console.log(`🔒 CORS: ${serverConfig.cors.origin}`);
            console.log(`\n📍 Rutas disponibles:`);
            console.log(`   - GET  http://localhost:${serverConfig.port}${serverConfig.app.apiPrefix}/`);
            console.log(`   - GET  http://localhost:${serverConfig.port}${serverConfig.app.apiPrefix}/health`);
            console.log(`   - POST http://localhost:${serverConfig.port}${serverConfig.app.apiPrefix}/auth/register`);
            console.log(`   - POST http://localhost:${serverConfig.port}${serverConfig.app.apiPrefix}/auth/login`);
            console.log(`   - GET  http://localhost:${serverConfig.port}${serverConfig.app.apiPrefix}/events`);
            console.log(`${'='.repeat(60)}\n`);
        });

    } catch (err) {
        console.error('💥 Error al iniciar el servidor:', err);
        process.exit(1);
    }
};

// ==================== GRACEFUL SHUTDOWN ====================
const gracefulShutdown = async (signal) => {
    console.log(`\n⚠️  Señal ${signal} recibida. Cerrando servidor...`);
    
    if (server) {
        server.close(async () => {
            console.log('🔌 Servidor HTTP cerrado.');
            
            try {
                await closeDatabase();
                console.log('✅ Cierre limpio completado.');
                process.exit(0);
            } catch (err) {
                console.error('❌ Error durante el cierre:', err);
                process.exit(1);
            }
        });
    }

    // Timeout de 10 segundos
    setTimeout(() => {
        console.error('⏰ Forzando cierre después de timeout.');
        process.exit(1);
    }, 10000);
};

// ==================== EVENT HANDLERS ====================
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

process.on('uncaughtException', (err) => {
    console.error('💥 Uncaught Exception:', err);
    gracefulShutdown('uncaughtException');
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('💥 Unhandled Rejection at:', promise, 'reason:', reason);
    gracefulShutdown('unhandledRejection');
});

// ==================== INICIAR ====================
startServer();