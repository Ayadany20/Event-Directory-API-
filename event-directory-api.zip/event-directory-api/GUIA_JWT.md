# 🔐 GUÍA COMPLETA DE JWT - Event Directory API

## 📋 Índice
1. [¿Qué es JWT?](#qué-es-jwt)
2. [Configuración](#configuración)
3. [Cómo funciona](#cómo-funciona)
4. [Ejemplos de uso](#ejemplos-de-uso)
5. [Middlewares disponibles](#middlewares-disponibles)
6. [Cómo implementar en endpoints](#cómo-implementar-en-endpoints)
7. [Tiempos de expiración](#tiempos-de-expiración)
8. [Troubleshooting](#troubleshooting)

---

## 🎯 ¿Qué es JWT?

**JWT (JSON Web Token)** es un estándar abierto (RFC 7519) que define una forma compacta y segura de transmitir información entre partes como un objeto JSON.

### Estructura de un JWT:
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiZW1haWwiOiJ1c2VyQGV4YW1wbGUuY29tIn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c
       [HEADER]                          .           [PAYLOAD]                    .            [SIGNATURE]
```

### Ventajas:
- ✅ **Stateless**: No requiere almacenamiento en servidor
- ✅ **Portable**: Funciona en web, mobile, IoT
- ✅ **Seguro**: Firma criptográfica
- ✅ **Compacto**: Fácil de transmitir

---

## ⚙️ Configuración

### 1. Variables de entorno (`.env`):

```env
# Configuración JWT
JWT_SECRET=tu_clave_super_secreta_cambiala_en_produccion_12345
JWT_EXPIRES_IN=24h
JWT_REFRESH_EXPIRES_IN=7d
JWT_ISSUER=event-directory-api
JWT_AUDIENCE=event-directory-app
```

### 2. Tiempos de expiración válidos:

| Valor | Significado | Uso recomendado |
|-------|-------------|-----------------|
| `15m` | 15 minutos | Producción alta seguridad |
| `1h` | 1 hora | Producción balanceado |
| `24h` | 24 horas | Desarrollo/Staging |
| `7d` | 7 días | Refresh tokens |
| `30d` | 30 días | Refresh tokens extendidos |

### 3. Significado de cada configuración:

- **JWT_SECRET**: Clave secreta para firmar tokens (NUNCA compartir)
- **JWT_EXPIRES_IN**: Tiempo de vida del access token
- **JWT_REFRESH_EXPIRES_IN**: Tiempo de vida del refresh token
- **JWT_ISSUER**: Quién emite el token (tu API)
- **JWT_AUDIENCE**: Para quién es el token (tu app)

---

## 🔄 Cómo funciona

### Flujo de autenticación:

```
1. Usuario → POST /api/v1/auth/login { email, password }
2. API valida credenciales
3. API genera tokens ← { accessToken, refreshToken }
4. Usuario guarda tokens (localStorage, sessionStorage, etc.)
5. Usuario → GET /api/v1/auth/profile 
   Header: Authorization: Bearer <accessToken>
6. API valida token y responde
```

### Ciclo de vida del token:

```
Login → AccessToken (24h) + RefreshToken (7d)
  ↓
Usuario hace peticiones con AccessToken
  ↓
AccessToken expira después de 24h
  ↓
Usuario usa RefreshToken para obtener nuevo AccessToken
  ↓
RefreshToken expira después de 7d → Usuario debe hacer login nuevamente
```

---

## 📝 Ejemplos de uso

### 1. **Registrar usuario**

```bash
curl -X POST http://localhost:3000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Juan Pérez",
    "email": "juan@example.com",
    "password": "Password123",
    "phone": "6641234567"
  }'
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Usuario registrado exitosamente",
  "data": {
    "user": {
      "id": 1,
      "name": "Juan Pérez",
      "email": "juan@example.com",
      "role": "user"
    },
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expiresIn": "24h"
  }
}
```

---

### 2. **Login**

```bash
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "juan@example.com",
    "password": "Password123"
  }'
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Login exitoso",
  "data": {
    "user": { ... },
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expiresIn": "24h"
  }
}
```

---

### 3. **Ver perfil (requiere token)**

```bash
curl -X GET http://localhost:3000/api/v1/auth/profile \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

**Respuesta:**
```json
{
  "success": true,
  "message": "Perfil obtenido exitosamente",
  "data": {
    "user": {
      "id": 1,
      "name": "Juan Pérez",
      "email": "juan@example.com",
      "role": "user"
    }
  }
}
```

---

### 4. **Actualizar perfil (requiere token)**

```bash
curl -X PUT http://localhost:3000/api/v1/auth/profile \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Juan Carlos Pérez",
    "phone": "6641112222"
  }'
```

---

## 🛡️ Middlewares disponibles

### 1. **verifyToken** - Autenticación OBLIGATORIA

```javascript
const { verifyToken } = require('../middlewares/auth.middleware');

// Uso en rutas
router.get('/profile', verifyToken, controller.getProfile);
```

**Qué hace:**
- ✅ Verifica que el header `Authorization: Bearer <token>` esté presente
- ✅ Valida que el token sea válido y no haya expirado
- ✅ Busca el usuario en la base de datos
- ✅ Verifica que el usuario esté activo
- ✅ Adjunta `req.user` con los datos del usuario

**Errores posibles:**
- `401`: Token no proporcionado
- `401`: Token inválido o expirado
- `401`: Usuario no encontrado
- `403`: Usuario inactivo

---

### 2. **checkRole** - Verificar roles específicos

```javascript
const { verifyToken, checkRole } = require('../middlewares/auth.middleware');

// Uso: solo administradores
router.delete('/users/:id', verifyToken, checkRole('admin'), controller.deleteUser);

// Uso: admin o organizador
router.post('/events', verifyToken, checkRole('admin', 'organizer'), controller.createEvent);
```

**Qué hace:**
- ✅ Verifica que el usuario esté autenticado (requiere `verifyToken` antes)
- ✅ Verifica que el rol del usuario esté en la lista de roles permitidos

**Errores posibles:**
- `401`: Usuario no autenticado
- `403`: Rol no autorizado

---

### 3. **requireEmailVerification** - Requiere email verificado

```javascript
const { verifyToken, requireEmailVerification } = require('../middlewares/auth.middleware');

// Uso
router.post('/events/:id/register', 
  verifyToken, 
  requireEmailVerification, 
  controller.registerToEvent
);
```

**Qué hace:**
- ✅ Verifica que el usuario esté autenticado
- ✅ Verifica que el usuario haya verificado su email

**Errores posibles:**
- `401`: Usuario no autenticado
- `403`: Email no verificado

---

### 4. **optionalAuth** - Autenticación OPCIONAL

```javascript
const { optionalAuth } = require('../middlewares/auth.middleware');

// Uso: ruta pública que cambia comportamiento si hay usuario
router.get('/events', optionalAuth, controller.getAllEvents);
```

**Qué hace:**
- ✅ Si hay token válido, adjunta `req.user`
- ✅ Si NO hay token o es inválido, `req.user = null`
- ✅ **NO genera error**, siempre continúa

**Ejemplo en controlador:**
```javascript
const getAllEvents = async (req, res) => {
  if (req.user) {
    // Usuario autenticado: mostrar eventos privados también
  } else {
    // Usuario anónimo: solo eventos públicos
  }
};
```

---

## 🔧 Cómo implementar en endpoints

### **Archivo: `src/routes/event.routes.js`**

Actualmente los endpoints de eventos **NO tienen JWT implementado**. Aquí están los ejemplos de cómo hacerlo:

#### Opción 1: Rutas públicas con auth opcional

```javascript
const { optionalAuth } = require('../middlewares/auth.middleware');

// Listar eventos (público, pero con más info si está autenticado)
router.get('/', optionalAuth, eventController.getAllEvents);
```

#### Opción 2: Crear evento solo con autenticación

```javascript
const { verifyToken } = require('../middlewares/auth.middleware');

router.post('/', verifyToken, eventController.createEvent);
```

#### Opción 3: Crear evento solo admin/organizador

```javascript
const { verifyToken, checkRole } = require('../middlewares/auth.middleware');

router.post('/', 
  verifyToken, 
  checkRole('admin', 'organizer'), 
  eventController.createEvent
);
```

#### Opción 4: Combinación completa

```javascript
const { verifyToken, checkRole, requireEmailVerification } = require('../middlewares/auth.middleware');

// Públicas
router.get('/', optionalAuth, eventController.getAllEvents);
router.get('/:id', optionalAuth, eventController.getEventById);

// Protegidas
router.post('/', 
  verifyToken, 
  checkRole('admin', 'organizer'), 
  eventController.createEvent
);

router.put('/:id', 
  verifyToken, 
  eventController.updateEvent
);

router.delete('/:id', 
  verifyToken, 
  checkRole('admin'), 
  eventController.deleteEvent
);

// Registrarse a evento (requiere email verificado)
router.post('/:id/register', 
  verifyToken, 
  requireEmailVerification, 
  eventController.registerToEvent
);
```

---

## ⏱️ Tiempos de expiración

### Configuración recomendada por ambiente:

#### **Desarrollo:**
```env
JWT_EXPIRES_IN=7d          # 7 días (conveniente para desarrollo)
JWT_REFRESH_EXPIRES_IN=30d # 30 días
```

#### **Staging:**
```env
JWT_EXPIRES_IN=24h         # 24 horas
JWT_REFRESH_EXPIRES_IN=7d  # 7 días
```

#### **Producción (seguridad normal):**
```env
JWT_EXPIRES_IN=1h          # 1 hora
JWT_REFRESH_EXPIRES_IN=7d  # 7 días
```

#### **Producción (alta seguridad):**
```env
JWT_EXPIRES_IN=15m         # 15 minutos
JWT_REFRESH_EXPIRES_IN=1d  # 1 día
```

### Tabla de referencia:

| Ambiente | Access Token | Refresh Token | Re-login |
|----------|--------------|---------------|----------|
| Dev | 7d | 30d | Casi nunca |
| Staging | 24h | 7d | Cada semana |
| Prod Normal | 1h | 7d | Cada semana |
| Prod Seguro | 15m | 1d | Cada día |

---

## 🐛 Troubleshooting

### Error: "Token no proporcionado"

```json
{
  "success": false,
  "message": "No se proporcionó token de autenticación",
  "error": "Token requerido en header: Authorization: Bearer <token>"
}
```

**Solución:** Incluir header `Authorization: Bearer <tu_token>`

---

### Error: "Token expirado"

```json
{
  "success": false,
  "message": "Token expirado",
  "error": "Token inválido o expirado"
}
```

**Soluciones:**
1. Hacer login nuevamente para obtener nuevo token
2. Usar el refresh token para obtener nuevo access token (TODO: implementar endpoint)

---

### Error: "Formato de token inválido"

```json
{
  "success": false,
  "message": "No se proporcionó token de autenticación"
}
```

**Solución:** Verificar formato correcto:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
              ^^^^^^ Palabra "Bearer" con mayúscula y espacio
```

---

### Error: "Usuario inactivo"

```json
{
  "success": false,
  "message": "Usuario inactivo",
  "error": "Tu cuenta ha sido desactivada"
}
```

**Solución:** Contactar al administrador para reactivar la cuenta

---

### Error: "Acceso denegado" (rol)

```json
{
  "success": false,
  "message": "Acceso denegado",
  "error": "Se requiere uno de los siguientes roles: admin, organizer",
  "yourRole": "user"
}
```

**Solución:** Este endpoint requiere un rol específico. No puedes acceder con tu rol actual.

---

## 📚 Recursos adicionales

- [JWT.io - Debugger](https://jwt.io/) - Decodificar y validar tokens
- [RFC 7519](https://tools.ietf.org/html/rfc7519) - Especificación oficial de JWT
- Documentación de jsonwebtoken: [npmjs.com/package/jsonwebtoken](https://www.npmjs.com/package/jsonwebtoken)

---

## 🎓 Próximos pasos

1. ✅ **Implementar JWT en rutas de eventos** (ver ejemplos arriba)
2. ⏳ **Crear endpoint de refresh token** (`POST /api/v1/auth/refresh`)
3. ⏳ **Implementar verificación de email** con tokens
4. ⏳ **Rate limiting** para prevenir fuerza bruta
5. ⏳ **Blacklist de tokens** para logout

---

**¡JWT completamente configurado y listo para usar!** 🎉
