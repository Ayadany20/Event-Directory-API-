# 📚 Guía de Relaciones entre Modelos

## 🎯 Resumen Visual de Relaciones

```
┌─────────────┐
│   Category  │
│             │
│ - id        │
│ - name      │
│ - slug      │
└──────┬──────┘
       │ 1
       │ hasMany (events)
       │
       │ N
┌──────▼──────────────┐         ┌─────────────┐
│      Event          │         │    User     │
│                     │         │             │
│ - id                │◄────────┤ - id        │
│ - title             │ N       │ - name      │
│ - categoryId   ─────┼─────────┤ - email     │
│ - createdBy         │ 1       │ - role      │
│ - maxCapacity       │         └──────┬──────┘
│ - availableSpots    │                │
│ - flyerUrl          │                │ 1
└──────┬──────────────┘                │ hasMany (tokens)
       │ 1                             │
       │ hasMany (registrations)       │ N
       │                               │
       │ N                        ┌────▼────────────────┐
┌──────▼──────────────────────┐  │ ConfirmationToken   │
│   EventRegistration         │  │                     │
│                             │  │ - id                │
│ - id                        │  │ - token             │
│ - eventId                   │  │ - type              │
│ - userId (puede ser null)   │  │ - userId            │
│ - attendeeName              │  │ - registrationId    │
│ - attendeeEmail        ─────┼──┤ - expiresAt         │
│ - confirmationToken         │  │ - isUsed            │
│ - isConfirmed               │  └─────────────────────┘
│ - qrCode                    │
│ - paymentStatus             │
└─────────────────────────────┘
```

---

## 📖 Explicación Detallada de Cada Relación

### 1️⃣ **Category → Event (1:N)**

```javascript
// Una categoría puede tener muchos eventos
Category.hasMany(Event, { 
  foreignKey: 'categoryId',
  as: 'events' 
});
```

**¿Qué significa?**
- Una categoría (ej: "Deportes") puede tener MUCHOS eventos (Maratón, Partido, etc.)
- Cada evento pertenece a UNA sola categoría

**Cómo usar:**
```javascript
// Obtener categoría con todos sus eventos
const category = await Category.findByPk(1, {
  include: [{
    model: Event,
    as: 'events'
  }]
});

console.log(category.name); // "Deportes"
console.log(category.events); // [Maratón, Partido de fútbol, ...]
```

**onDelete: 'NO ACTION'** → Si intentas borrar una categoría que tiene eventos, dará ERROR. Primero debes borrar o reasignar los eventos.

---

### 2️⃣ **User → Event (Creador) (1:N)**

```javascript
// Un usuario puede crear muchos eventos
User.hasMany(Event, { 
  foreignKey: 'createdBy',
  as: 'createdEvents' 
});
```

**¿Qué significa?**
- Un usuario (ej: "Juan") puede CREAR muchos eventos
- Cada evento fue creado por UN solo usuario

**Cómo usar:**
```javascript
// Obtener todos los eventos creados por un usuario
const user = await User.findByPk(1, {
  include: [{
    model: Event,
    as: 'createdEvents'
  }]
});

console.log(user.name); // "Juan"
console.log(user.createdEvents); // [Concierto Rock, Conferencia Tech, ...]
```

**onDelete: 'NO ACTION'** → No puedes borrar un usuario que haya creado eventos.

---

### 3️⃣ **Event → EventRegistration (1:N)**

```javascript
// Un evento puede tener muchos registros de asistentes
Event.hasMany(EventRegistration, { 
  foreignKey: 'eventId',
  as: 'registrations',
  onDelete: 'CASCADE' 
});
```

**¿Qué significa?**
- Un evento (ej: "Concierto Rock") puede tener MUCHOS asistentes registrados
- Cada registro pertenece a UN solo evento

**Cómo usar:**
```javascript
// Obtener evento con todos los asistentes registrados
const event = await Event.findByPk(1, {
  include: [{
    model: EventRegistration,
    as: 'registrations'
  }]
});

console.log(event.title); // "Concierto Rock"
console.log(event.registrations.length); // 150 asistentes
console.log(event.registrations[0].attendeeName); // "Pedro García"
```

**onDelete: 'CASCADE'** → Si borras un evento, TODOS sus registros se borran automáticamente.

---

### 4️⃣ **User → EventRegistration (Asistente) (1:N)**

```javascript
// Un usuario puede registrarse a muchos eventos
User.hasMany(EventRegistration, { 
  foreignKey: 'userId',
  as: 'eventRegistrations',
  onDelete: 'SET NULL' 
});
```

**¿Qué significa?**
- Un usuario (ej: "María") puede registrarse a MUCHOS eventos
- Un registro PUEDE tener un usuario (o null si es invitado)

**Cómo usar:**
```javascript
// Obtener todos los eventos a los que se registró un usuario
const user = await User.findByPk(1, {
  include: [{
    model: EventRegistration,
    as: 'eventRegistrations',
    include: [{
      model: Event,
      as: 'event'
    }]
  }]
});

console.log(user.name); // "María"
user.eventRegistrations.forEach(reg => {
  console.log(reg.event.title); // "Concierto Rock", "Maratón", ...
});
```

**onDelete: 'SET NULL'** → Si borras un usuario, sus registros NO se borran, pero el campo `userId` se pone en `null`.

---

### 5️⃣ **EventRegistration → ConfirmationToken (1:N)**

```javascript
// Un registro puede tener varios tokens (si expiran y se regeneran)
EventRegistration.hasMany(ConfirmationToken, { 
  foreignKey: 'registrationId',
  as: 'confirmationTokens',
  onDelete: 'CASCADE' 
});
```

**¿Qué significa?**
- Un registro puede tener VARIOS tokens (si el primero expira, se genera otro)
- Cada token pertenece a UN registro específico

**Cómo usar:**
```javascript
// Obtener registro con su historial de tokens
const registration = await EventRegistration.findByPk(1, {
  include: [{
    model: ConfirmationToken,
    as: 'confirmationTokens'
  }]
});

console.log(registration.attendeeName); // "Pedro García"
registration.confirmationTokens.forEach(token => {
  console.log(token.token); // "abc123...", "xyz789..."
  console.log(token.isUsed); // true, false
});
```

**onDelete: 'CASCADE'** → Si cancelas/borras un registro, todos sus tokens se borran.

---

### 6️⃣ **User → ConfirmationToken (1:N)**

```javascript
// Un usuario puede tener varios tokens de diferentes tipos
User.hasMany(ConfirmationToken, { 
  foreignKey: 'userId',
  as: 'tokens',
  onDelete: 'CASCADE' 
});
```

**¿Qué significa?**
- Un usuario puede tener VARIOS tipos de tokens:
  - `event_registration` → Para confirmar asistencia
  - `email_verification` → Para verificar email
  - `password_reset` → Para restablecer contraseña

**Cómo usar:**
```javascript
// Obtener todos los tokens de un usuario
const user = await User.findByPk(1, {
  include: [{
    model: ConfirmationToken,
    as: 'tokens'
  }]
});

console.log(user.name); // "Ana"
user.tokens.forEach(token => {
  console.log(`${token.type}: ${token.isUsed ? 'Usado' : 'Activo'}`);
});
// email_verification: Usado
// password_reset: Activo
```

**onDelete: 'CASCADE'** → Si borras un usuario, todos sus tokens se borran.

---

## 🔑 Glosario de Opciones

### **onDelete**
Define qué pasa cuando borras el registro "padre":

- `CASCADE` → Borra en cascada (borra también los registros relacionados)
- `SET NULL` → Pone NULL en el campo de la relación
- `NO ACTION` → NO permite borrar si existen registros relacionados (da error)
- `RESTRICT` → Similar a NO ACTION

### **onUpdate**
Define qué pasa cuando actualizas el ID del registro "padre":

- `CASCADE` → Actualiza en cascada (actualiza el ID en registros relacionados)
- `NO ACTION` → NO permite actualizar si existen registros relacionados

### **foreignKey**
El nombre del campo que almacena la relación en la base de datos.

### **as**
El alias que se usa para acceder a la relación en el código.

---

## 💡 Ejemplos Prácticos Completos

### Ejemplo 1: Crear evento con categoría
```javascript
const db = require('./models');

// Buscar categoría "Música"
const categoria = await db.Category.findOne({ 
  where: { slug: 'musica' } 
});

// Crear evento en esa categoría
const evento = await db.Event.create({
  title: 'Festival de Rock 2025',
  description: 'El mejor festival del año',
  categoryId: categoria.id,
  createdBy: 1, // ID del usuario creador
  maxCapacity: 5000,
  availableSpots: 5000,
  startDate: new Date('2025-12-01'),
  endDate: new Date('2025-12-03'),
  slug: 'festival-rock-2025'
});
```

### Ejemplo 2: Registrar usuario a evento
```javascript
// Buscar evento
const evento = await db.Event.findOne({ 
  where: { slug: 'festival-rock-2025' } 
});

// Verificar espacios disponibles
if (evento.availableSpots > 0) {
  // Crear registro
  const registro = await db.EventRegistration.create({
    eventId: evento.id,
    userId: 5, // Usuario logueado (o null si es invitado)
    attendeeName: 'Carlos Pérez',
    attendeeEmail: 'carlos@email.com',
    attendeePhone: '555-1234',
    numberOfGuests: 2
  });

  // Actualizar espacios disponibles
  await evento.update({
    availableSpots: evento.availableSpots - registro.numberOfGuests
  });

  console.log('✅ Registro exitoso');
} else {
  console.log('❌ Evento lleno');
}
```

### Ejemplo 3: Generar token de confirmación
```javascript
const crypto = require('crypto');

// Crear token de confirmación
const token = crypto.randomBytes(32).toString('hex');

await db.ConfirmationToken.create({
  token,
  type: 'event_registration',
  registrationId: registro.id,
  userId: 5,
  email: 'carlos@email.com',
  expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 horas
});

// Aquí enviarías el email con el token
console.log(`Token de confirmación: ${token}`);
```

### Ejemplo 4: Confirmar asistencia con token
```javascript
// Buscar token
const tokenData = await db.ConfirmationToken.findOne({
  where: { 
    token: 'abc123...',
    isUsed: false
  },
  include: [{
    model: db.EventRegistration,
    as: 'registration'
  }]
});

if (!tokenData) {
  console.log('❌ Token inválido');
} else if (new Date() > tokenData.expiresAt) {
  console.log('❌ Token expirado');
} else {
  // Confirmar registro
  await tokenData.registration.update({
    isConfirmed: true,
    confirmationDate: new Date()
  });

  // Marcar token como usado
  await tokenData.update({
    isUsed: true,
    usedAt: new Date()
  });

  console.log('✅ Asistencia confirmada');
}
```

---

## 🎓 Consultas Útiles con Include

### Obtener evento completo con toda la información
```javascript
const eventoCompleto = await db.Event.findByPk(1, {
  include: [
    {
      model: db.Category,
      as: 'category',
      attributes: ['name', 'slug']
    },
    {
      model: db.User,
      as: 'creator',
      attributes: ['name', 'email']
    },
    {
      model: db.EventRegistration,
      as: 'registrations',
      include: [{
        model: db.User,
        as: 'user',
        attributes: ['name', 'email']
      }]
    }
  ]
});

console.log(eventoCompleto.title);
console.log(eventoCompleto.category.name);
console.log(eventoCompleto.creator.name);
console.log(`Asistentes: ${eventoCompleto.registrations.length}`);
```

### Obtener usuario con todos sus eventos
```javascript
const usuario = await db.User.findByPk(1, {
  include: [
    {
      model: db.Event,
      as: 'createdEvents', // Eventos que CREÓ
      include: [{
        model: db.Category,
        as: 'category'
      }]
    },
    {
      model: db.EventRegistration,
      as: 'eventRegistrations', // Eventos a los que SE REGISTRÓ
      include: [{
        model: db.Event,
        as: 'event'
      }]
    }
  ]
});

console.log(`Eventos creados: ${usuario.createdEvents.length}`);
console.log(`Eventos registrado: ${usuario.eventRegistrations.length}`);
```

---

## 🚨 Errores Comunes y Soluciones

### Error 1: "Cannot read property 'name' of null"
```javascript
// ❌ MAL: No incluir la relación
const evento = await db.Event.findByPk(1);
console.log(evento.category.name); // ERROR

// ✅ BIEN: Incluir la relación
const evento = await db.Event.findByPk(1, {
  include: [{ model: db.Category, as: 'category' }]
});
console.log(evento.category.name); // ✅ Funciona
```

### Error 2: "is not associated to..."
```javascript
// ❌ MAL: Usar alias incorrecto
include: [{ model: db.Category, as: 'categorias' }] // No existe

// ✅ BIEN: Usar el alias correcto definido en index.js
include: [{ model: db.Category, as: 'category' }] // ✅
```

### Error 3: No se puede borrar por relaciones
```javascript
// ❌ Error: No se puede borrar categoría con eventos
await db.Category.destroy({ where: { id: 1 } }); 
// ERROR: onDelete: 'NO ACTION'

// ✅ SOLUCIÓN 1: Borrar primero los eventos
await db.Event.destroy({ where: { categoryId: 1 } });
await db.Category.destroy({ where: { id: 1 } });

// ✅ SOLUCIÓN 2: Reasignar eventos a otra categoría
await db.Event.update(
  { categoryId: 2 },
  { where: { categoryId: 1 } }
);
await db.Category.destroy({ where: { id: 1 } });
```

---

## 📌 Resumen Final

| Relación | Tipo | onDelete | Significado |
|----------|------|----------|-------------|
| Category → Event | 1:N | NO ACTION | No borrar categoría con eventos |
| User → Event (creador) | 1:N | NO ACTION | No borrar creador con eventos |
| Event → Registration | 1:N | CASCADE | Borrar registros si borra evento |
| User → Registration | 1:N | SET NULL | Mantener registros si borra usuario |
| Registration → Token | 1:N | CASCADE | Borrar tokens si borra registro |
| User → Token | 1:N | CASCADE | Borrar tokens si borra usuario |

¡Con esta guía ya puedes trabajar con todas las relaciones de tu base de datos! 🎉
